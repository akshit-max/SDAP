"use strict";
(() => {
  // src/providers/registry.ts
  function getProviderForHost(hostname) {
    for (const adapter of PROVIDER_REGISTRY) {
      for (const domain of adapter.domains) {
        if (hostname === domain || hostname.endsWith(`.${domain}`)) {
          return adapter;
        }
      }
    }
    return null;
  }
  var GoDaddyProvider = {
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    getCredentialFields() {
      const username = document.querySelector('#username, input[name="username"], input[type="email"]');
      const password = document.querySelector('#password, input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: '#username, input[name="username"], input[type="email"]',
        passwordSelector: '#password, input[name="password"], input[type="password"]',
        submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]'
      };
    }
  };
  var HostingerProvider = {
    name: "Hostinger",
    domains: ["hostinger.com", "hpanel.hostinger.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="email"], input[type="email"]');
      const password = document.querySelector('input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="email"], input[type="email"]',
        passwordSelector: 'input[name="password"], input[type="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var CPanelProvider = {
    name: "cPanel",
    domains: ["cpanel.net", "cpanelhosting.net"],
    getCredentialFields() {
      const username = document.querySelector('#login_form input[name="user"], input#username, input[name="username"]');
      const password = document.querySelector('#login_form input[name="pass"], input#password, input[name="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: '#login_form input[name="user"], input#username',
        passwordSelector: '#login_form input[name="pass"], input#password',
        submitSelector: '#login_btn, input[type="submit"]'
      };
    }
  };
  var SiteGroundProvider = {
    name: "SiteGround",
    domains: ["siteground.com", "my.siteground.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="email"], input[type="email"]');
      const password = document.querySelector('input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="email"], input[type="email"]',
        passwordSelector: 'input[name="password"], input[type="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var GitHubProvider = {
    name: "GitHub",
    domains: ["github.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="login"], input#login_field');
      const password = document.querySelector('input[name="password"], input#password');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="login"], input#login_field',
        passwordSelector: 'input[name="password"], input#password',
        submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
      };
    }
  };
  var VercelProvider = {
    name: "Vercel",
    domains: ["vercel.com"],
    getCredentialFields() {
      const username = document.querySelector('input[type="email"], input[name="email"]');
      if (!username)
        return null;
      return {
        usernameSelector: 'input[type="email"], input[name="email"]',
        passwordSelector: 'input[type="password"], input[name="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var PROVIDER_REGISTRY = [
    GoDaddyProvider,
    HostingerProvider,
    CPanelProvider,
    SiteGroundProvider,
    GitHubProvider,
    VercelProvider
  ];

  // src/providers/platform-registry.ts
  var PlatformRegistry = class {
    constructor() {
      this.configs = /* @__PURE__ */ new Map();
    }
    register(config2) {
      this.configs.set(config2.id, config2);
    }
    getForHost(hostname) {
      for (const config2 of this.configs.values()) {
        for (const domain of config2.domains) {
          if (hostname === domain || hostname.endsWith(`.${domain}`)) {
            return config2;
          }
        }
      }
      return null;
    }
    getAll() {
      return Array.from(this.configs.values());
    }
  };
  var platformRegistry = new PlatformRegistry();
  platformRegistry.register({
    id: "GITHUB",
    name: "GitHub",
    domains: ["github.com"],
    login: {
      url: "https://github.com/login",
      usernameSelector: 'input[name="login"], input#login_field',
      passwordSelector: 'input[name="password"], input#password',
      submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
    },
    principalType: "GITHUB_USERNAME",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "VERCEL",
    name: "Vercel",
    domains: ["vercel.com"],
    login: {
      url: "https://vercel.com/login",
      usernameSelector: 'input[type="email"], input[name="email"]',
      passwordSelector: 'input[type="password"], input[name="password"]',
      submitSelector: 'button[type="submit"]'
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[autocomplete="one-time-code"], input[inputmode="numeric"], input[type="number"], input[name="code"], input[type="text"][maxlength="1"]'
    },
    principalType: "EMAIL",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "GODADDY",
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    login: {
      url: "https://sso.godaddy.com/",
      usernameSelector: '#username, input[name="username"], input[type="email"]',
      passwordSelector: '#password, input[name="password"], input[type="password"]',
      submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]',
      requirePasswordOnDOM: true
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[aria-label="Hide password" i]',
      "#password",
      "div:has(> input#password)"
    ],
    principalType: "EMAIL",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com", "www.linkedin.com"],
    login: {
      url: "https://www.linkedin.com/checkpoint/lg/login?trk=hb_signin",
      usernameSelector: 'input[name="session_key"], #session_key, input[autocomplete="username"], input[autocomplete="email"], input[type="email"], #username',
      passwordSelector: 'input[name="session_password"], #session_password, input[autocomplete="current-password"], input[type="password"], #password',
      submitSelector: 'button[type="submit"], button[aria-label="Sign in"], .login__form_action_container button'
    }
  });
  platformRegistry.register({
    id: "SHOPIFY",
    name: "Shopify",
    domains: ["shopify.com", "accounts.shopify.com", "admin.shopify.com"],
    login: {
      url: "https://admin.shopify.com/login",
      usernameSelector: 'input[type="email"], input[autocomplete="username"], #account_email',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], #account_password',
      submitSelector: 'button[type="submit"], button[name="commit"]'
    },
    hideElementsCSS: [
      "button.js-password-button",
      'button[aria-controls="account_password"]',
      "#account_password",
      ".password-wrapper:has(#account_password)"
    ]
  });
  platformRegistry.register({
    id: "STRIPE",
    name: "Stripe",
    domains: ["stripe.com", "dashboard.stripe.com"],
    login: {
      url: "https://dashboard.stripe.com/login",
      usernameSelector: 'input[type="email"], input[name="email"], input[autocomplete="username"]',
      passwordSelector: 'input[type="password"], input[name="password"], input[autocomplete="current-password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-testid="login-button"]'
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[name="verification_code"]',
      submitSelector: 'button[type="submit"]'
    }
  });
  platformRegistry.register({
    id: "RAZORPAY",
    name: "Razorpay",
    // Only accounts.razorpay.com is the login/auth subdomain.
    // dashboard.razorpay.com is the post-login dashboard — removing it prevents
    // the extension from showing the "Logging you in..." toast on the dashboard page.
    domains: ["accounts.razorpay.com"],
    login: {
      url: "https://accounts.razorpay.com/auth",
      usernameSelector: 'input[type="email"], input[type="text"], input[type="tel"], input[autocomplete="username"], input[autocomplete="email"]',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], input[placeholder*="password" i]',
      submitSelector: 'button[type="submit"], button#btn-login, #btn-login, button.btn-primary, button[data-testid="btn-submit"]'
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[data-blade-component="icon-button"] svg'
    ],
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[inputmode="numeric"][maxlength="1"], input[type="number"][maxlength="1"]',
      // Specific selectors first. button[type="submit"] is the safe fallback since
      // after all 6 digits are filled, the only submit-type button on this page is Verify.
      // We deliberately removed button:not([disabled]) as it matched Resend/Back first.
      submitSelector: 'button[data-testid="btn-verify"], button[data-testid="verify-btn"], button[type="submit"]'
    }
  });
  platformRegistry.register({
    id: "MCA",
    name: "MCA Portal",
    domains: ["www.mca.gov.in", "mca.gov.in"],
    login: {
      url: "https://www.mca.gov.in/content/mca/global/en/foportal/fologin.html",
      // User ID: accepts CIN/LLPIN/FCRN for companies or email for other users.
      // NOTE: input[type="text"] or form-based fallbacks are BANNED here.
      // The MCA header contains a search bar form that appears before the login
      // form in the DOM, so generic fallbacks will match the search bar.
      usernameSelector: [
        'input[name="userID" i]',
        // exact match from DOM (case-insensitive)
        'input[name="userId" i]',
        'input[name="loginid" i]',
        ".userID input",
        // wrapper class from DOM
        ".user-id-input input"
        // wrapper class from DOM
      ].join(", "),
      passwordSelector: [
        'input[type="password"]',
        'input[name="password"]',
        'input[id="password"]'
      ].join(", ")
      // No submitSelector Ã¢â‚¬â€ manualStepMessage prevents auto-submit
    },
    manualStepMessage: "Credentials filled. Please complete the CAPTCHA to continue."
  });
  platformRegistry.register({
    id: "GST",
    name: "GST Portal",
    domains: ["gst.gov.in", "services.gst.gov.in"],
    login: {
      url: "https://services.gst.gov.in/services/login",
      // Specific name/id selectors only Ã¢â‚¬â€ intentionally exclude input[type="text"]
      // to prevent matching the CAPTCHA field which is also type=text on this page.
      usernameSelector: [
        "#user_name",
        'input[name="user_name"]',
        'input[id="user_name"]',
        'input[name="username"]',
        'input[id="username"]'
      ].join(", "),
      passwordSelector: [
        "#user_pass",
        // Exact ID match based on DOM snippet
        'input[name="user_pass"]',
        // GST-specific: confirmed from portal DOM
        'input[id="user_pass"]',
        'input[type="password"]',
        // standard fallback
        'input[name="password"]'
      ].join(", ")
      // No submitSelector Ã¢â‚¬â€ manualStepMessage prevents auto-submit
    },
    manualStepMessage: "Credentials filled. Please complete the CAPTCHA and OTP verification to continue."
  });
  platformRegistry.register({
    id: "UDYAM",
    name: "Udyam Portal",
    domains: ["udyamregistration.gov.in"],
    login: {
      url: "https://udyamregistration.gov.in",
      usernameSelector: [
        'input[name="udyam_no"]',
        'input[id="udyam_no"]',
        'input[name="Udyam_No"]',
        'input[name="udyamNo"]',
        'input[placeholder*="Udyam" i]',
        'input[placeholder*="Registration Number" i]',
        'input[maxlength="19"]'
        // Registration numbers are exactly 19 chars
      ].join(", ")
      // No passwordSelector — mobile number is NOT represented here.
      // Architecture Preservation Directive: do not overload passwordSelector semantics.
    },
    manualStepMessage: 'Udyam Registration Number filled. Please enter your mobile number and click "Validate & Generate OTP" to receive your OTP.'
  });
  platformRegistry.register({
    id: "GOOGLE_ADS",
    name: "Google Ads",
    domains: ["ads.google.com", "accounts.google.com"],
    login: {
      url: "https://ads.google.com/",
      usernameSelector: 'input[type="email"], input[name="identifier"], input#identifierId'
      // Deliberately omitting passwordSelector to respect the frozen architecture
      // and prevent breaking on Google's two-step flow and passkey mandates.
    },
    manualStepMessage: 'Email filled. Google requires manual sign-in due to passkey / 2FA / account chooser. Click "Next" and continue manually.'
  });

  // src/content/autofill.ts
  var provider = null;
  var otpCompleted = false;
  var loginStartTime = Date.now();
  var config = platformRegistry.getForHost(location.hostname);
  if (config && config.login && config.login.usernameSelector) {
    provider = {
      name: config.name,
      domains: config.domains,
      getCredentialFields: () => {
        const usernameExists = document.querySelector(config.login.usernameSelector);
        const passwordExists = config.login.passwordSelector ? document.querySelector(config.login.passwordSelector) : null;
        if (!usernameExists && !passwordExists)
          return null;
        return {
          usernameSelector: config.login.usernameSelector,
          passwordSelector: config.login.passwordSelector,
          submitSelector: config.login.submitSelector
        };
      }
    };
  } else {
    provider = getProviderForHost(location.hostname);
  }
  if (!provider) {
  }
  var activeSessions = [];
  var activeOrgId = "";
  async function discoverSessions() {
    const response = await sendMessage({
      type: "GET_ACTIVE_SESSION",
      payload: { domain: location.hostname }
    });
    if (!response.success || !response.data?.sessions.length)
      return;
    activeSessions = response.data.sessions;
    activeOrgId = response.data.orgId;
    const checkAndActivate = () => {
      const fields = provider?.getCredentialFields();
      if (!fields)
        return false;
      const hasUsername = fields.usernameSelector ? !!document.querySelector(fields.usernameSelector) : false;
      const hasPassword = fields.passwordSelector ? !!document.querySelector(fields.passwordSelector) : false;
      return hasUsername || hasPassword;
    };
    if (checkAndActivate()) {
      handleAutofillRequest();
      return;
    }
    if (config?.otp) {
      const otpFields = Array.from(document.querySelectorAll(config.otp.inputSelector));
      const visibleOtpField = otpFields.find((f) => isOtpFieldVisible(f));
      if (visibleOtpField) {
        startOtpWatcher(activeSessions[0].id, activeOrgId, loginStartTime);
        return;
      }
    }
    let formWatchAttempts = 0;
    const MAX_FORM_WAIT_ATTEMPTS = 40;
    const formWatcher = new MutationObserver(() => {
      formWatchAttempts++;
      if (formWatchAttempts > MAX_FORM_WAIT_ATTEMPTS) {
        formWatcher.disconnect();
        return;
      }
      if (checkAndActivate()) {
        formWatcher.disconnect();
        handleAutofillRequest();
      } else if (config?.otp) {
        const otpFields = Array.from(document.querySelectorAll(config.otp.inputSelector));
        if (otpFields.find((f) => isOtpFieldVisible(f))) {
          formWatcher.disconnect();
          startOtpWatcher(activeSessions[0].id, activeOrgId, loginStartTime);
        }
      }
    });
    formWatcher.observe(document.body, { childList: true, subtree: true });
  }
  function showToast(message, isError = false) {
    let toast = document.getElementById("withus-magic-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "withus-magic-toast";
      toast.style.cssText = [
        "position:fixed",
        "top:24px",
        "right:24px",
        "z-index:2147483647",
        "background:#030303",
        "color:#ffffff",
        "border-radius:8px",
        "padding:12px 20px",
        "font-family:system-ui,sans-serif",
        "font-size:13px",
        "font-weight:600",
        "box-shadow:0 10px 40px rgba(0,0,0,0.5)",
        "display:flex",
        "align-items:center",
        "gap:10px",
        "user-select:none",
        "border:1px solid rgba(255,255,255,0.15)",
        "transition:opacity 0.3s ease, transform 0.3s ease",
        "opacity:0",
        "transform:translateY(-10px)"
      ].join(";");
      document.body.appendChild(toast);
      requestAnimationFrame(() => {
        toast.style.opacity = "1";
        toast.style.transform = "translateY(0)";
      });
    }
    const icon = isError ? "\u274C" : '<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#22c55e;flex-shrink:0"></span>';
    toast.innerHTML = `${icon} ${message}`;
    if (isError) {
      toast.style.background = "#030303";
      toast.style.border = "1px solid rgba(239, 68, 68, 0.4)";
      toast.style.color = "#ef4444";
      setTimeout(() => {
        toast?.style.setProperty("opacity", "0");
        toast?.style.setProperty("transform", "translateY(-10px)");
        setTimeout(() => toast?.remove(), 300);
      }, 4e3);
    }
  }
  function removeToast() {
    const toast = document.getElementById("withus-magic-toast");
    if (toast) {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(-10px)";
      setTimeout(() => toast.remove(), 300);
    }
  }
  async function handleAutofillRequest() {
    const session = activeSessions.sort((a, b) => a.revealCount - b.revealCount)[0];
    if (!session)
      return;
    loginStartTime = Date.now();
    showToast("WithUs session detected... Logging you in...");
    await new Promise((resolve) => setTimeout(resolve, 1e3));
    const response = await sendMessage({
      type: "LAUNCH_SESSION",
      payload: { sessionId: session.id, orgId: session.__orgId || activeOrgId }
    });
    if (!response.success || !response.data) {
      showToast(response.error || "Failed to retrieve credentials.", true);
      return;
    }
    const { username, password } = response.data;
    const fields = provider?.getCredentialFields();
    if (!fields) {
      showToast("Could not detect login form on this page.", true);
      return;
    }
    try {
      const pwEls = fields.passwordSelector ? Array.from(document.querySelectorAll(fields.passwordSelector)) : [];
      const pwEl = pwEls.find((el) => isOtpFieldVisible(el));
      if (fields.usernameSelector && username) {
        const usernameEls = Array.from(document.querySelectorAll(fields.usernameSelector));
        const usernameEl = usernameEls.find((el) => isOtpFieldVisible(el));
        if (usernameEl && usernameEl !== pwEl) {
          fillField(usernameEl, username);
          await new Promise((r) => setTimeout(r, 150));
        }
      }
      if (!password) {
        showToast("\u26A0\uFE0F WARNING: No password found in your vault! Please update it in the web dashboard.", true);
        await new Promise((r) => setTimeout(r, 3e3));
      }
      if (fields.passwordSelector && password) {
        if (pwEl) {
          try {
            fillField(pwEl, password);
          } catch {
          }
        } else {
          startPasswordWatcher(
            fields.passwordSelector,
            fields.submitSelector,
            password,
            session.id,
            session.__orgId || activeOrgId
          );
        }
      }
      provider?.afterFill?.();
      if (config?.hideElementsCSS && config.hideElementsCSS.length > 0) {
        const styleId = "withus-hide-elements";
        if (!document.getElementById(styleId)) {
          const style = document.createElement("style");
          style.id = styleId;
          style.textContent = `${config.hideElementsCSS.join(", ")} {
          display: none !important;
          pointer-events: none !important;
          visibility: hidden !important;
          opacity: 0 !important;
        }`;
          document.head.appendChild(style);
          setTimeout(() => document.getElementById(styleId)?.remove(), 3e4);
        }
      }
      if (config?.manualStepMessage) {
        showToast(config.manualStepMessage);
        return;
      }
      if (config?.otp) {
        startOtpWatcher(session.id, session.__orgId || activeOrgId, loginStartTime);
      }
      await new Promise((r) => setTimeout(r, 200));
      clickSubmitButton(fields.submitSelector);
    } catch {
      showToast("Autofill failed \u2014 please fill in manually.", true);
    } finally {
      response.data = null;
    }
  }
  function fillField(selectorOrEl, value, skipFocus = false) {
    const el = typeof selectorOrEl === "string" ? document.querySelector(selectorOrEl) : selectorOrEl;
    if (!el)
      throw new Error(`Field not found: ${selectorOrEl}`);
    if (!skipFocus)
      el.focus();
    const nativeInputSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value"
    )?.set;
    const tracker = el._valueTracker;
    if (tracker)
      tracker.setValue("");
    try {
      nativeInputSetter?.call(el, value);
    } catch {
    }
    el.value = value;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: value.slice(-1) }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: value.slice(-1) }));
  }
  function clickSubmitButton(selector, maxAttempts = 10, intervalMs = 150) {
    const SUBMIT_LABELS = /* @__PURE__ */ new Set(["login", "log in", "continue", "verify", "submit", "next", "sign in", "signin", "proceed"]);
    const SOCIAL_KEYWORDS = ["google", "microsoft", "apple", "facebook", "github", "twitter", "sso", "saml"];
    const tryFind = () => {
      if (selector) {
        const els = Array.from(document.querySelectorAll(selector));
        const visible = els.find((el) => {
          if (el.disabled)
            return false;
          const rect = el.getBoundingClientRect();
          if (rect.width === 0 || rect.height === 0)
            return false;
          const text = el.textContent?.toLowerCase() ?? "";
          return !SOCIAL_KEYWORDS.some((kw) => text.includes(kw));
        });
        if (visible)
          return visible;
      }
      return Array.from(document.querySelectorAll("button")).find((btn) => {
        if (btn.disabled)
          return false;
        const rect = btn.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0)
          return false;
        const text = btn.textContent?.trim().toLowerCase() ?? "";
        if (SOCIAL_KEYWORDS.some((kw) => text.includes(kw)))
          return false;
        return SUBMIT_LABELS.has(text);
      }) ?? null;
    };
    let attempts = 0;
    const retry = () => {
      attempts++;
      const btn = tryFind();
      if (btn) {
        btn.click();
        return;
      }
      if (attempts < maxAttempts) {
        setTimeout(retry, intervalMs);
      }
    };
    retry();
  }
  function startPasswordWatcher(passwordSelector, submitSelector, password, sessionId, orgId) {
    const observer = new MutationObserver(() => {
      const pwEls = Array.from(document.querySelectorAll(passwordSelector));
      const pwEl = pwEls.find((el) => isOtpFieldVisible(el));
      if (!pwEl)
        return;
      observer.disconnect();
      clearTimeout(timeout);
      try {
        fillField(pwEl, password);
        if (config?.otp)
          startOtpWatcher(sessionId, orgId, loginStartTime);
        clickSubmitButton(submitSelector);
      } catch {
        showToast("Password autofill failed \u2014 please enter manually.", true);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    const timeout = setTimeout(() => observer.disconnect(), 3e4);
  }
  function startOtpWatcher(sessionId, orgId, startTime) {
    if (otpCompleted)
      return;
    const otpConfig = config?.otp;
    if (!otpConfig)
      return;
    const existingOtpFields = Array.from(document.querySelectorAll(otpConfig.inputSelector));
    const existingOtpField = existingOtpFields.find((f) => isOtpFieldVisible(f));
    if (existingOtpField && document.visibilityState === "visible") {
      otpCompleted = true;
      fetchAndFillOtp(sessionId, orgId, otpConfig.inputSelector, otpConfig.submitSelector, existingOtpField, config?.id, startTime);
      return;
    }
    let otpRequested = false;
    const observer = new MutationObserver(() => {
      if (otpRequested)
        return;
      const otpFields = Array.from(document.querySelectorAll(otpConfig.inputSelector));
      const otpField = otpFields.find((f) => isOtpFieldVisible(f));
      if (!otpField)
        return;
      if (document.visibilityState !== "visible")
        return;
      otpCompleted = true;
      otpRequested = true;
      observer.disconnect();
      clearTimeout(hardTimeout);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      fetchAndFillOtp(sessionId, orgId, otpConfig.inputSelector, otpConfig.submitSelector, otpField, config?.id, startTime);
    });
    observer.observe(document.body, { childList: true, subtree: true });
    const hardTimeout = setTimeout(() => {
      observer.disconnect();
      document.removeEventListener("visibilitychange", onVisibilityChange);
    }, 3e4);
    function onVisibilityChange() {
      if (document.visibilityState === "hidden") {
        observer.disconnect();
        clearTimeout(hardTimeout);
        document.removeEventListener("visibilitychange", onVisibilityChange);
      }
    }
    document.addEventListener("visibilitychange", onVisibilityChange);
  }
  function isOtpFieldVisible(el) {
    if (el.disabled || el.hidden)
      return false;
    if (el.type === "hidden")
      return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  async function fetchAndFillOtp(sessionId, orgId, inputSelector, submitSelector, resolvedOtpField, platform, loginStartTime2) {
    let otpCode = null;
    try {
      showToast("Fetching verification code...");
      const response = await sendMessage({
        type: "FETCH_OTP",
        // Include the platform so the backend can use a sender-specific Gmail search
        // Include the loginStartTime so the backend only picks up NEW emails
        payload: { sessionId, orgId, platform, loginStartTime: loginStartTime2 }
      });
      if (!response.success || !response.data?.otp) {
        const msg = response.error || "No OTP found.";
        if (msg.toLowerCase().includes("not connected") || msg.toLowerCase().includes("gmail")) {
          showToast(
            "Automatic OTP is unavailable \u2014 the account owner has not connected Gmail to WithUs. Ask the organization owner to enable Gmail integration.",
            true
          );
        } else if (msg.toLowerCase().includes("not found") || msg.toLowerCase().includes("no otp")) {
          showToast("No OTP found. Please request a new verification code.", true);
        } else if (msg.toLowerCase().includes("unavailable") || msg.toLowerCase().includes("rate")) {
          showToast("Gmail temporarily unavailable. Please try again in a moment.", true);
        } else {
          showToast(msg, true);
        }
        return;
      }
      otpCode = response.data.otp;
      console.log("\u2705 WITHUS EXTRACTED OTP:", otpCode);
      let otpField = resolvedOtpField;
      if (otpField && !isOtpFieldVisible(otpField)) {
        otpField = void 0;
      }
      if (!otpField) {
        const otpFields = Array.from(document.querySelectorAll(inputSelector));
        otpField = otpFields.find((f) => isOtpFieldVisible(f));
      }
      if (!otpField) {
        showToast("Could not locate the OTP field.", true);
        return;
      }
      const allOtpBoxes = Array.from(document.querySelectorAll(inputSelector)).filter((f) => isOtpFieldVisible(f));
      if (allOtpBoxes.length > 1 && otpCode.length === allOtpBoxes.length) {
        for (let i = 0; i < allOtpBoxes.length; i++) {
          const box = allOtpBoxes[i];
          const digit = otpCode[i];
          box.focus();
          box.dispatchEvent(new KeyboardEvent("keydown", { key: digit, bubbles: true }));
          const nativeSetter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype,
            "value"
          )?.set;
          nativeSetter?.call(box, digit);
          box.dispatchEvent(new Event("input", { bubbles: true }));
          box.dispatchEvent(new Event("change", { bubbles: true }));
          box.dispatchEvent(new KeyboardEvent("keyup", { key: digit, bubbles: true }));
        }
      } else {
        fillField(otpField, otpCode);
      }
      if (submitSelector) {
        const isMultiBox = allOtpBoxes.length > 1;
        const submitDelay = isMultiBox ? 700 : 120;
        setTimeout(() => {
          const btn = document.querySelector(submitSelector);
          if (btn && !btn.disabled && isOtpFieldVisible(btn)) {
            btn.click();
          }
        }, submitDelay);
      }
      removeToast();
    } catch {
      showToast("OTP autofill failed. Please enter the code manually.", true);
    } finally {
      otpCode = null;
    }
  }
  function sendMessage(msg) {
    try {
      const promise = chrome.runtime.sendMessage(msg);
      return promise.catch((error) => {
        if (error?.message?.includes("Extension context invalidated")) {
          alert("WithUs Extension was updated. The page will now refresh to apply changes.");
          window.location.reload();
          return new Promise(() => {
          });
        }
        throw error;
      });
    } catch (error) {
      if (error?.message?.includes("Extension context invalidated")) {
        alert("WithUs Extension was updated. The page will now refresh to apply changes.");
        window.location.reload();
        return new Promise(() => {
        });
      }
      throw error;
    }
  }
  window.addEventListener("withus:autofill", async (e) => {
    const { sessionId, orgId } = e.detail;
    const response = await sendMessage({
      type: "LAUNCH_SESSION",
      payload: { sessionId, orgId }
    });
    if (!response.success || !response.data)
      return;
    const { username, password } = response.data;
    const session = activeSessions.find((s) => s.id === sessionId);
    const fallbackUsername = session?.resourceName || session?.secretName || "";
    const fields = provider?.getCredentialFields();
    if (!fields) {
      showToast("Failed to find login fields on this page.", true);
      return;
    }
    try {
      if (fields.usernameSelector) {
        const usernameEl = document.querySelector(fields.usernameSelector);
        if (usernameEl && isOtpFieldVisible(usernameEl)) {
          fillField(usernameEl, username || fallbackUsername);
        }
      }
      if (fields.passwordSelector && password) {
        try {
          fillField(fields.passwordSelector, password);
        } catch {
        }
      }
      provider?.afterFill?.();
      if (config?.otp) {
        startOtpWatcher(sessionId, orgId, loginStartTime);
      }
      clickSubmitButton(fields.submitSelector);
    } catch (err) {
      showToast(err.message || "Failed to fill credentials", true);
    } finally {
      response.data = null;
    }
  });
  if (provider) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", discoverSessions);
    } else {
      discoverSessions();
    }
  }
})();
