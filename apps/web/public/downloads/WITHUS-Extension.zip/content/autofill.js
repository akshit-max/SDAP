"use strict";
(() => {
  // src/providers/registry.ts
  function getProviderForHost(hostname) {
    for (const adapter of PROVIDER_REGISTRY) {
      for (const domain of adapter.domains) {
        if (hostname === domain || hostname.endsWith(`.${domain}`)) {
          return adapter;
        }
      }
    }
    return null;
  }
  var GoDaddyProvider = {
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    getCredentialFields() {
      const username = document.querySelector('#username, input[name="username"], input[type="email"]');
      const password = document.querySelector('#password, input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: '#username, input[name="username"], input[type="email"]',
        passwordSelector: '#password, input[name="password"], input[type="password"]',
        submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]'
      };
    }
  };
  var HostingerProvider = {
    name: "Hostinger",
    domains: ["hostinger.com", "hpanel.hostinger.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="email"], input[type="email"]');
      const password = document.querySelector('input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="email"], input[type="email"]',
        passwordSelector: 'input[name="password"], input[type="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var CPanelProvider = {
    name: "cPanel",
    domains: ["cpanel.net", "cpanelhosting.net"],
    getCredentialFields() {
      const username = document.querySelector('#login_form input[name="user"], input#username, input[name="username"]');
      const password = document.querySelector('#login_form input[name="pass"], input#password, input[name="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: '#login_form input[name="user"], input#username',
        passwordSelector: '#login_form input[name="pass"], input#password',
        submitSelector: '#login_btn, input[type="submit"]'
      };
    }
  };
  var SiteGroundProvider = {
    name: "SiteGround",
    domains: ["siteground.com", "my.siteground.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="email"], input[type="email"]');
      const password = document.querySelector('input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="email"], input[type="email"]',
        passwordSelector: 'input[name="password"], input[type="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var GitHubProvider = {
    name: "GitHub",
    domains: ["github.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="login"], input#login_field');
      const password = document.querySelector('input[name="password"], input#password');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="login"], input#login_field',
        passwordSelector: 'input[name="password"], input#password',
        submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
      };
    }
  };
  var VercelProvider = {
    name: "Vercel",
    domains: ["vercel.com"],
    getCredentialFields() {
      const username = document.querySelector('input[type="email"], input[name="email"]');
      if (!username)
        return null;
      return {
        usernameSelector: 'input[type="email"], input[name="email"]',
        passwordSelector: 'input[type="password"], input[name="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var PROVIDER_REGISTRY = [
    GoDaddyProvider,
    HostingerProvider,
    CPanelProvider,
    SiteGroundProvider,
    GitHubProvider,
    VercelProvider
  ];

  // src/providers/platform-registry.ts
  var PlatformRegistry = class {
    constructor() {
      this.configs = /* @__PURE__ */ new Map();
    }
    register(config2) {
      this.configs.set(config2.id, config2);
    }
    getForHost(hostname) {
      for (const config2 of this.configs.values()) {
        for (const domain of config2.domains) {
          if (hostname === domain || hostname.endsWith(`.${domain}`)) {
            return config2;
          }
        }
      }
      return null;
    }
    getAll() {
      return Array.from(this.configs.values());
    }
  };
  var platformRegistry = new PlatformRegistry();
  platformRegistry.register({
    id: "GITHUB",
    name: "GitHub",
    domains: ["github.com"],
    login: {
      url: "https://github.com/login",
      usernameSelector: 'input[name="login"], input#login_field',
      passwordSelector: 'input[name="password"], input#password',
      submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
    },
    principalType: "GITHUB_USERNAME",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "VERCEL",
    name: "Vercel",
    domains: ["vercel.com"],
    login: {
      url: "https://vercel.com/login",
      usernameSelector: 'input[type="email"], input[name="email"]',
      passwordSelector: 'input[type="password"], input[name="password"]',
      submitSelector: 'button[type="submit"]'
    },
    principalType: "EMAIL",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "GODADDY",
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    login: {
      url: "https://sso.godaddy.com/",
      usernameSelector: '#username, input[name="username"], input[type="email"]',
      passwordSelector: '#password, input[name="password"], input[type="password"]',
      submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]',
      requirePasswordOnDOM: true
    },
    principalType: "EMAIL",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com", "www.linkedin.com"],
    login: {
      url: "https://www.linkedin.com/login",
      usernameSelector: 'input[name="session_key"], input[autocomplete="username"], input[type="email"], #username',
      passwordSelector: 'input[name="session_password"], input[autocomplete="current-password"], input[type="password"], #password',
      submitSelector: 'button[type="submit"], button[aria-label="Sign in"], .login__form_action_container button, form button'
    }
  });
  platformRegistry.register({
    id: "SHOPIFY",
    name: "Shopify",
    domains: ["shopify.com", "accounts.shopify.com", "admin.shopify.com"],
    login: {
      url: "https://admin.shopify.com/login",
      usernameSelector: 'input[type="email"], input[autocomplete="username"], #account_email',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], #account_password',
      submitSelector: 'button[type="submit"], button[name="commit"]'
    }
  });
  platformRegistry.register({
    id: "STRIPE",
    name: "Stripe",
    domains: ["stripe.com", "dashboard.stripe.com"],
    login: {
      url: "https://dashboard.stripe.com/login",
      usernameSelector: 'input[type="email"], input[name="email"], input[autocomplete="username"]',
      passwordSelector: 'input[type="password"], input[name="password"], input[autocomplete="current-password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-testid="login-button"]'
    },
    /**
     * OTP Config (Phase 7A)
     *
     * Supported: Email verification code (enforced on every login)
     *
     * Deferred to Phase 7B+:
     * - Authenticator app TOTP
     * - SMS OTP
     */
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[name="verification_code"]',
      submitSelector: 'button[type="submit"]'
    }
  });
  platformRegistry.register({
    id: "RAZORPAY",
    name: "Razorpay",
    domains: ["razorpay.com", "dashboard.razorpay.com"],
    login: {
      url: "https://dashboard.razorpay.com/signin",
      usernameSelector: 'input[type="email"], input[type="text"], input[type="tel"], input[autocomplete="username"]',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"]',
      submitSelector: 'button[type="submit"]'
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"]'
    }
  });

  // src/content/autofill.ts
  var provider = null;
  var otpCompleted = false;
  var config = platformRegistry.getForHost(location.hostname);
  if (config && config.login && config.login.usernameSelector && config.login.passwordSelector && config.login.submitSelector) {
    provider = {
      name: config.name,
      domains: config.domains,
      getCredentialFields: () => {
        const usernameExists = document.querySelector(config.login.usernameSelector);
        if (!usernameExists)
          return null;
        if (config.login.requirePasswordOnDOM) {
          const passwordExists = document.querySelector(config.login.passwordSelector);
          if (!passwordExists)
            return null;
        }
        return {
          usernameSelector: config.login.usernameSelector,
          passwordSelector: config.login.passwordSelector,
          submitSelector: config.login.submitSelector
        };
      }
    };
  } else {
    provider = getProviderForHost(location.hostname);
  }
  if (!provider) {
    throw new Error("WITHUS: unsupported domain, content script exiting");
  }
  var activeSessions = [];
  var activeOrgId = "";
  async function discoverSessions() {
    const response = await sendMessage({
      type: "GET_ACTIVE_SESSION",
      payload: { domain: location.hostname }
    });
    if (!response.success || !response.data?.sessions.length)
      return;
    activeSessions = response.data.sessions;
    activeOrgId = response.data.orgId;
    if (provider?.getCredentialFields()) {
      handleAutofillRequest();
    }
  }
  function showToast(message, isError = false) {
    let toast = document.getElementById("withus-magic-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "withus-magic-toast";
      toast.style.cssText = [
        "position:fixed",
        "top:24px",
        "right:24px",
        "z-index:2147483647",
        "background:#030303",
        "color:#ffffff",
        "border-radius:8px",
        "padding:12px 20px",
        "font-family:system-ui,sans-serif",
        "font-size:13px",
        "font-weight:600",
        "box-shadow:0 10px 40px rgba(0,0,0,0.5)",
        "display:flex",
        "align-items:center",
        "gap:10px",
        "user-select:none",
        "border:1px solid rgba(255,255,255,0.15)",
        "transition:opacity 0.3s ease, transform 0.3s ease",
        "opacity:0",
        "transform:translateY(-10px)"
      ].join(";");
      document.body.appendChild(toast);
      requestAnimationFrame(() => {
        toast.style.opacity = "1";
        toast.style.transform = "translateY(0)";
      });
    }
    const icon = isError ? "\u274C" : '<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#22c55e;flex-shrink:0"></span>';
    toast.innerHTML = `${icon} ${message}`;
    if (isError) {
      toast.style.background = "#030303";
      toast.style.border = "1px solid rgba(239, 68, 68, 0.4)";
      toast.style.color = "#ef4444";
      setTimeout(() => {
        toast?.style.setProperty("opacity", "0");
        toast?.style.setProperty("transform", "translateY(-10px)");
        setTimeout(() => toast?.remove(), 300);
      }, 4e3);
    }
  }
  function removeToast() {
    const toast = document.getElementById("withus-magic-toast");
    if (toast) {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(-10px)";
      setTimeout(() => toast.remove(), 300);
    }
  }
  async function handleAutofillRequest() {
    const session = activeSessions.sort((a, b) => a.revealCount - b.revealCount)[0];
    if (!session)
      return;
    showToast("WithUs session detected... Logging you in...");
    await new Promise((resolve) => setTimeout(resolve, 1e3));
    const response = await sendMessage({
      type: "LAUNCH_SESSION",
      payload: { sessionId: session.id, orgId: session.__orgId || activeOrgId }
    });
    if (!response.success || !response.data) {
      showToast(response.error || "Failed to retrieve credentials.", true);
      return;
    }
    const { username, password } = response.data;
    const fields = provider?.getCredentialFields();
    if (!fields) {
      showToast("Could not detect login form on this page.", true);
      return;
    }
    try {
      if (fields.usernameSelector) {
        fillField(fields.usernameSelector, username);
      }
      if (fields.passwordSelector && password) {
        try {
          fillField(fields.passwordSelector, password);
        } catch {
        }
      }
      provider?.afterFill?.();
      if (fields.submitSelector) {
        const submitBtn = document.querySelector(fields.submitSelector);
        if (submitBtn) {
          setTimeout(() => {
            submitBtn.click();
            if (config?.otp) {
              startOtpWatcher(session.id, session.__orgId || activeOrgId);
            }
          }, 120);
        }
      }
    } catch {
      showToast("Autofill failed \u2014 please fill in manually.", true);
    } finally {
      response.data = null;
    }
  }
  function fillField(selector, value) {
    const el = document.querySelector(selector);
    if (!el)
      throw new Error(`Field not found: ${selector}`);
    const nativeInputSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value"
    )?.set;
    nativeInputSetter?.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function startOtpWatcher(sessionId, orgId) {
    if (otpCompleted)
      return;
    const otpConfig = config?.otp;
    if (!otpConfig)
      return;
    let otpRequested = false;
    const observer = new MutationObserver(() => {
      if (otpRequested)
        return;
      const otpField = document.querySelector(otpConfig.inputSelector);
      if (!otpField)
        return;
      if (document.visibilityState !== "visible")
        return;
      if (!isOtpFieldVisible(otpField))
        return;
      otpCompleted = true;
      otpRequested = true;
      observer.disconnect();
      clearTimeout(hardTimeout);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      fetchAndFillOtp(sessionId, orgId, otpConfig.inputSelector, otpConfig.submitSelector);
    });
    observer.observe(document.body, { childList: true, subtree: true });
    const hardTimeout = setTimeout(() => {
      observer.disconnect();
      document.removeEventListener("visibilitychange", onVisibilityChange);
    }, 3e4);
    function onVisibilityChange() {
      if (document.visibilityState === "hidden") {
        observer.disconnect();
        clearTimeout(hardTimeout);
        document.removeEventListener("visibilitychange", onVisibilityChange);
      }
    }
    document.addEventListener("visibilitychange", onVisibilityChange);
  }
  function isOtpFieldVisible(el) {
    if (el.disabled || el.hidden)
      return false;
    if (el.type === "hidden")
      return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  async function fetchAndFillOtp(sessionId, orgId, inputSelector, submitSelector) {
    let otpCode = null;
    try {
      showToast("Fetching verification code...");
      const response = await sendMessage({
        type: "FETCH_OTP",
        payload: { sessionId, orgId }
      });
      if (!response.success || !response.data?.otp) {
        const msg = response.error || "No OTP found.";
        if (msg.toLowerCase().includes("not connected") || msg.toLowerCase().includes("gmail")) {
          showToast(
            "Automatic OTP is unavailable \u2014 the account owner has not connected Gmail to WithUs. Ask the organization owner to enable Gmail integration.",
            true
          );
        } else if (msg.toLowerCase().includes("not found") || msg.toLowerCase().includes("no otp")) {
          showToast("No OTP found. Please request a new verification code.", true);
        } else if (msg.toLowerCase().includes("unavailable") || msg.toLowerCase().includes("rate")) {
          showToast("Gmail temporarily unavailable. Please try again in a moment.", true);
        } else {
          showToast(msg, true);
        }
        return;
      }
      otpCode = response.data.otp;
      const otpField = document.querySelector(inputSelector);
      if (!otpField || !isOtpFieldVisible(otpField)) {
        showToast("Could not locate the OTP field.", true);
        return;
      }
      fillField(inputSelector, otpCode);
      if (submitSelector) {
        const submitBtn = document.querySelector(submitSelector);
        if (submitBtn && !submitBtn.disabled && isOtpFieldVisible(submitBtn)) {
          setTimeout(() => submitBtn.click(), 120);
        }
      }
      removeToast();
    } catch {
      showToast("OTP autofill failed. Please enter the code manually.", true);
    } finally {
      otpCode = null;
    }
  }
  function sendMessage(msg) {
    try {
      const promise = chrome.runtime.sendMessage(msg);
      return promise.catch((error) => {
        if (error?.message?.includes("Extension context invalidated")) {
          alert("WithUs Extension was updated. The page will now refresh to apply changes.");
          window.location.reload();
          return new Promise(() => {
          });
        }
        throw error;
      });
    } catch (error) {
      if (error?.message?.includes("Extension context invalidated")) {
        alert("WithUs Extension was updated. The page will now refresh to apply changes.");
        window.location.reload();
        return new Promise(() => {
        });
      }
      throw error;
    }
  }
  window.addEventListener("withus:autofill", async (e) => {
    const { sessionId, orgId } = e.detail;
    const response = await sendMessage({
      type: "LAUNCH_SESSION",
      payload: { sessionId, orgId }
    });
    if (!response.success || !response.data)
      return;
    const { username, password } = response.data;
    const session = activeSessions.find((s) => s.id === sessionId);
    const fallbackUsername = session?.resourceName || session?.secretName || "";
    const fields = provider?.getCredentialFields();
    if (!fields) {
      showToast("Failed to find login fields on this page.", true);
      return;
    }
    try {
      if (fields.usernameSelector) {
        fillField(fields.usernameSelector, username || fallbackUsername);
      }
      if (fields.passwordSelector && password) {
        try {
          fillField(fields.passwordSelector, password);
        } catch {
        }
      }
      provider?.afterFill?.();
      if (fields.submitSelector) {
        const submitBtn = document.querySelector(fields.submitSelector);
        if (submitBtn)
          setTimeout(() => submitBtn.click(), 120);
        else
          showToast("Could not find submit button.", true);
      }
    } catch (err) {
      showToast(err.message || "Failed to fill credentials", true);
    } finally {
      response.data = null;
    }
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", discoverSessions);
  } else {
    discoverSessions();
  }
})();
