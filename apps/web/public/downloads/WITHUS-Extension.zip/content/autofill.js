"use strict";
(() => {
  // src/providers/registry.ts
  function getProviderForHost(hostname) {
    for (const adapter of PROVIDER_REGISTRY) {
      for (const domain of adapter.domains) {
        if (hostname === domain || hostname.endsWith(`.${domain}`)) {
          return adapter;
        }
      }
    }
    return null;
  }
  var GoDaddyProvider = {
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    getCredentialFields() {
      const username = document.querySelector('#username, input[name="username"], input[type="email"]');
      const password = document.querySelector('#password, input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: '#username, input[name="username"], input[type="email"]',
        passwordSelector: '#password, input[name="password"], input[type="password"]',
        submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]'
      };
    }
  };
  var HostingerProvider = {
    name: "Hostinger",
    domains: ["hostinger.com", "hpanel.hostinger.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="email"], input[type="email"]');
      const password = document.querySelector('input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="email"], input[type="email"]',
        passwordSelector: 'input[name="password"], input[type="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var CPanelProvider = {
    name: "cPanel",
    domains: ["cpanel.net", "cpanelhosting.net"],
    getCredentialFields() {
      const username = document.querySelector('#login_form input[name="user"], input#username, input[name="username"]');
      const password = document.querySelector('#login_form input[name="pass"], input#password, input[name="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: '#login_form input[name="user"], input#username',
        passwordSelector: '#login_form input[name="pass"], input#password',
        submitSelector: '#login_btn, input[type="submit"]'
      };
    }
  };
  var SiteGroundProvider = {
    name: "SiteGround",
    domains: ["siteground.com", "my.siteground.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="email"], input[type="email"]');
      const password = document.querySelector('input[name="password"], input[type="password"]');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="email"], input[type="email"]',
        passwordSelector: 'input[name="password"], input[type="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var GitHubProvider = {
    name: "GitHub",
    domains: ["github.com"],
    getCredentialFields() {
      const username = document.querySelector('input[name="login"], input#login_field');
      const password = document.querySelector('input[name="password"], input#password');
      if (!username || !password)
        return null;
      return {
        usernameSelector: 'input[name="login"], input#login_field',
        passwordSelector: 'input[name="password"], input#password',
        submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
      };
    }
  };
  var VercelProvider = {
    name: "Vercel",
    domains: ["vercel.com"],
    getCredentialFields() {
      const username = document.querySelector('input[type="email"], input[name="email"]');
      if (!username)
        return null;
      return {
        usernameSelector: 'input[type="email"], input[name="email"]',
        passwordSelector: 'input[type="password"], input[name="password"]',
        submitSelector: 'button[type="submit"]'
      };
    }
  };
  var PROVIDER_REGISTRY = [
    GoDaddyProvider,
    HostingerProvider,
    CPanelProvider,
    SiteGroundProvider,
    GitHubProvider,
    VercelProvider
  ];

  // src/content/autofill.ts
  var provider = getProviderForHost(location.hostname);
  if (!provider) {
    throw new Error("WITHUS: unsupported domain, content script exiting");
  }
  var activeSessions = [];
  var activeOrgId = "";
  async function discoverSessions() {
    const response = await sendMessage({
      type: "GET_ACTIVE_SESSION",
      payload: { domain: location.hostname }
    });
    if (!response.success || !response.data?.sessions.length)
      return;
    activeSessions = response.data.sessions;
    activeOrgId = response.data.orgId;
    if (provider?.getCredentialFields()) {
      handleAutofillRequest();
    }
  }
  function showToast(message, isError = false) {
    let toast = document.getElementById("withus-magic-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "withus-magic-toast";
      toast.style.cssText = [
        "position:fixed",
        "top:24px",
        "right:24px",
        "z-index:2147483647",
        "background:#1e293b",
        "color:#f8fafc",
        "border-radius:12px",
        "padding:12px 20px",
        "font-family:system-ui,sans-serif",
        "font-size:14px",
        "font-weight:500",
        "box-shadow:0 8px 30px rgba(0,0,0,0.4)",
        "display:flex",
        "align-items:center",
        "gap:12px",
        "user-select:none",
        "border:1px solid rgba(255,255,255,0.1)",
        "transition:opacity 0.3s ease, transform 0.3s ease",
        "opacity:0",
        "transform:translateY(-10px)"
      ].join(";");
      document.body.appendChild(toast);
      requestAnimationFrame(() => {
        toast.style.opacity = "1";
        toast.style.transform = "translateY(0)";
      });
    }
    const icon = isError ? "\u274C" : '<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#22c55e;flex-shrink:0"></span>';
    toast.innerHTML = `${icon} ${message}`;
    if (isError) {
      toast.style.background = "#7f1d1d";
      setTimeout(() => {
        toast?.style.setProperty("opacity", "0");
        toast?.style.setProperty("transform", "translateY(-10px)");
        setTimeout(() => toast?.remove(), 300);
      }, 4e3);
    }
  }
  async function handleAutofillRequest() {
    const session = activeSessions.sort((a, b) => a.revealCount - b.revealCount)[0];
    if (!session)
      return;
    showToast("WITHUS session detected... Logging you in...");
    await new Promise((resolve) => setTimeout(resolve, 1e3));
    const response = await sendMessage({
      type: "LAUNCH_SESSION",
      payload: { sessionId: session.id, orgId: session.__orgId || activeOrgId }
    });
    if (!response.success || !response.data) {
      showToast(response.error || "Failed to retrieve credentials.", true);
      return;
    }
    const { username, password } = response.data;
    const fields = provider?.getCredentialFields();
    if (!fields) {
      showToast("Could not detect login form on this page.", true);
      return;
    }
    try {
      if (fields.usernameSelector) {
        fillField(fields.usernameSelector, username);
      }
      if (fields.passwordSelector && password) {
        try {
          fillField(fields.passwordSelector, password);
        } catch {
        }
      }
      provider?.afterFill?.();
      if (fields.submitSelector) {
        const submitBtn = document.querySelector(fields.submitSelector);
        if (submitBtn) {
          setTimeout(() => submitBtn.click(), 120);
        }
      }
    } catch {
      showToast("Autofill failed \u2014 please fill in manually.", true);
    } finally {
      response.data = null;
    }
  }
  function fillField(selector, value) {
    const el = document.querySelector(selector);
    if (!el)
      throw new Error(`Field not found: ${selector}`);
    const nativeInputSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value"
    )?.set;
    nativeInputSetter?.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function sendMessage(msg) {
    try {
      const promise = chrome.runtime.sendMessage(msg);
      return promise.catch((error) => {
        if (error?.message?.includes("Extension context invalidated")) {
          alert("WITHUS Extension was updated. The page will now refresh to apply changes.");
          window.location.reload();
          return new Promise(() => {
          });
        }
        throw error;
      });
    } catch (error) {
      if (error?.message?.includes("Extension context invalidated")) {
        alert("WITHUS Extension was updated. The page will now refresh to apply changes.");
        window.location.reload();
        return new Promise(() => {
        });
      }
      throw error;
    }
  }
  window.addEventListener("withus:autofill", async (e) => {
    const { sessionId, orgId } = e.detail;
    const response = await sendMessage({
      type: "LAUNCH_SESSION",
      payload: { sessionId, orgId }
    });
    if (!response.success || !response.data)
      return;
    const { username, password } = response.data;
    const session = activeSessions.find((s) => s.id === sessionId);
    const fallbackUsername = session?.resourceName || session?.secretName || "";
    const fields = provider?.getCredentialFields();
    if (!fields)
      return;
    try {
      fillField(fields.usernameSelector, username || fallbackUsername);
      fillField(fields.passwordSelector, password);
      provider?.afterFill?.();
      if (fields.submitSelector) {
        const submitBtn = document.querySelector(fields.submitSelector);
        if (submitBtn)
          setTimeout(() => submitBtn.click(), 120);
      }
    } finally {
      response.data = null;
    }
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", discoverSessions);
  } else {
    discoverSessions();
  }
})();
