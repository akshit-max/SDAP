"use strict";
(() => {
  // src/providers/platform-registry.ts
  var PlatformRegistry = class {
    constructor() {
      this.configs = /* @__PURE__ */ new Map();
    }
    register(config) {
      this.configs.set(config.id, config);
    }
    getForHost(hostname) {
      for (const config of this.configs.values()) {
        for (const domain of config.domains) {
          if (hostname === domain || hostname.endsWith(`.${domain}`)) {
            return config;
          }
        }
      }
      return null;
    }
    getAll() {
      return Array.from(this.configs.values());
    }
  };
  var platformRegistry = new PlatformRegistry();
  platformRegistry.register({
    id: "GITHUB",
    name: "GitHub",
    domains: ["github.com"],
    login: {
      url: "https://github.com/login",
      usernameSelector: 'input[name="login"], input#login_field',
      passwordSelector: 'input[name="password"], input#password',
      submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
    },
    principalType: "GITHUB_USERNAME",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "VERCEL",
    name: "Vercel",
    domains: ["vercel.com"],
    login: {
      url: "https://vercel.com/login",
      usernameSelector: 'input[type="email"], input[name="email"]',
      passwordSelector: 'input[type="password"], input[name="password"]',
      submitSelector: 'button[type="submit"]'
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[autocomplete="one-time-code"], input[inputmode="numeric"], input[type="number"], input[name="code"], input[type="text"][maxlength="1"]'
    },
    principalType: "EMAIL",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "GODADDY",
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    login: {
      url: "https://sso.godaddy.com/",
      usernameSelector: '#username, input[name="username"], input[type="email"]',
      passwordSelector: '#password, input[name="password"], input[type="password"]',
      submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]',
      requirePasswordOnDOM: true
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[aria-label="Hide password" i]',
      "#password",
      "div:has(> input#password)"
    ],
    principalType: "EMAIL",
    supportsDelegation: true
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com", "www.linkedin.com"],
    login: {
      url: "https://www.linkedin.com/checkpoint/lg/login?trk=hb_signin",
      usernameSelector: 'input[name="session_key"], #session_key, input[autocomplete="username"], input[autocomplete="email"], input[type="email"], #username',
      passwordSelector: 'input[name="session_password"], #session_password, input[autocomplete="current-password"], input[type="password"], #password',
      submitSelector: 'button[type="submit"], button[aria-label="Sign in"], .login__form_action_container button'
    }
  });
  platformRegistry.register({
    id: "SHOPIFY",
    name: "Shopify",
    domains: ["shopify.com", "accounts.shopify.com", "admin.shopify.com"],
    login: {
      url: "https://admin.shopify.com/login",
      usernameSelector: 'input[type="email"], input[autocomplete="username"], #account_email',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], #account_password',
      submitSelector: 'button[type="submit"], button[name="commit"]'
    },
    hideElementsCSS: [
      "button.js-password-button",
      'button[aria-controls="account_password"]',
      "#account_password",
      ".password-wrapper:has(#account_password)"
    ]
  });
  platformRegistry.register({
    id: "STRIPE",
    name: "Stripe",
    domains: ["stripe.com", "dashboard.stripe.com"],
    login: {
      url: "https://dashboard.stripe.com/login",
      usernameSelector: 'input[type="email"], input[name="email"], input[autocomplete="username"]',
      passwordSelector: 'input[type="password"], input[name="password"], input[autocomplete="current-password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-testid="login-button"]'
    },
    hideElementsCSS: [
      'input[data-testid="login-password-input"]',
      "#old-password",
      'div:has(> input[data-testid="login-password-input"])',
      "div:has(> input#old-password)"
    ],
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[name="verification_code"]',
      submitSelector: 'button[type="submit"]'
    }
  });
  platformRegistry.register({
    id: "RAZORPAY",
    name: "Razorpay",
    // Only accounts.razorpay.com is the login/auth subdomain.
    // dashboard.razorpay.com is the post-login dashboard — removing it prevents
    // the extension from showing the "Logging you in..." toast on the dashboard page.
    domains: ["accounts.razorpay.com"],
    login: {
      url: "https://accounts.razorpay.com/auth",
      usernameSelector: 'input[type="email"], input[type="text"], input[type="tel"], input[autocomplete="username"], input[autocomplete="email"]',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], input[placeholder*="password" i]',
      submitSelector: 'button[type="submit"], button#btn-login, #btn-login, button.btn-primary, button[data-testid="btn-submit"]'
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[data-blade-component="icon-button"] svg'
    ],
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[inputmode="numeric"][maxlength="1"], input[type="number"][maxlength="1"]',
      // Specific selectors first. button[type="submit"] is the safe fallback since
      // after all 6 digits are filled, the only submit-type button on this page is Verify.
      // We deliberately removed button:not([disabled]) as it matched Resend/Back first.
      submitSelector: 'button[data-testid="btn-verify"], button[data-testid="verify-btn"], button[type="submit"]'
    }
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com"],
    login: {
      url: "https://www.linkedin.com/login",
      usernameSelector: 'input[name="session_key"], input#username, input[type="text"], input[type="email"]',
      passwordSelector: 'input[name="session_password"], input#password, input[type="password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-litms-control-urn="login-submit"]'
    },
    hideElementsCSS: [
      'input[type="password"][autocomplete="current-password"]',
      'button[aria-label="Show password" i]',
      "button:has(svg#visibility-small)",
      'div:has(> input[type="password"][autocomplete="current-password"])'
    ]
  });
  platformRegistry.register({
    id: "MCA",
    name: "MCA Portal",
    domains: ["www.mca.gov.in", "mca.gov.in"],
    login: {
      url: "https://www.mca.gov.in/content/mca/global/en/foportal/fologin.html",
      // User ID: accepts CIN/LLPIN/FCRN for companies or email for other users.
      // NOTE: input[type="text"] or form-based fallbacks are BANNED here.
      // The MCA header contains a search bar form that appears before the login
      // form in the DOM, so generic fallbacks will match the search bar.
      usernameSelector: [
        'input[name="userID" i]',
        // exact match from DOM (case-insensitive)
        'input[name="userId" i]',
        'input[name="loginid" i]',
        ".userID input",
        // wrapper class from DOM
        ".user-id-input input"
        // wrapper class from DOM
      ].join(", "),
      passwordSelector: [
        'input[type="password"]',
        'input[name="password"]',
        'input[id="password"]'
      ].join(", ")
      // No submitSelector — manualStepMessage prevents auto-submit
    },
    manualStepMessage: "WithUs Vault: Secure session activated. Please resolve the CAPTCHA to proceed.",
    capabilityRestrictions: {
      "mca.master_data": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/master-data.html"])'] },
      "mca.llp_efiling": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/llp-e-filling.html"])'] },
      "mca.fo_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/fo-llp-services.html"])'] },
      "mca.dsc_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/dsc-services-v3.html"])'] },
      "mca.company_efiling": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/e-filing.html"])'] },
      "mca.complaints": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/complaints.html"])'] },
      "mca.document_related_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/document-related-services.html"])'] },
      "mca.payment_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/fee-and-payment-services.html"])'] },
      "mca.id_databank": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/id-databank-services.html"])'] }
    }
  });
  platformRegistry.register({
    id: "GST",
    name: "GST Portal",
    domains: ["gst.gov.in", "services.gst.gov.in"],
    login: {
      url: "https://services.gst.gov.in/services/login",
      // Specific name/id selectors only Ã¢â‚¬â€ intentionally exclude input[type="text"]
      // to prevent matching the CAPTCHA field which is also type=text on this page.
      usernameSelector: [
        "#user_name",
        'input[name="user_name"]',
        'input[id="user_name"]',
        'input[name="username"]',
        'input[id="username"]'
      ].join(", "),
      passwordSelector: [
        "#user_pass",
        // Exact ID match based on DOM snippet
        'input[name="user_pass"]',
        // GST-specific: confirmed from portal DOM
        'input[id="user_pass"]',
        'input[type="password"]',
        // standard fallback
        'input[name="password"]'
      ].join(", ")
      // No submitSelector Ã¢â‚¬â€ manualStepMessage prevents auto-submit
    },
    manualStepMessage: "Credentials filled. Please complete the CAPTCHA and OTP verification to continue."
  });
  platformRegistry.register({
    id: "UDYAM",
    name: "Udyam Portal",
    domains: ["udyamregistration.gov.in"],
    login: {
      url: "https://udyamregistration.gov.in",
      usernameSelector: [
        'input[name="udyam_no"]',
        'input[id="udyam_no"]',
        'input[name="Udyam_No"]',
        'input[name="udyamNo"]',
        'input[placeholder*="Udyam" i]',
        'input[placeholder*="Registration Number" i]',
        'input[maxlength="19"]'
        // Registration numbers are exactly 19 chars
      ].join(", ")
      // No passwordSelector — mobile number is NOT represented here.
      // Architecture Preservation Directive: do not overload passwordSelector semantics.
    },
    manualStepMessage: 'Udyam Registration Number filled. Please enter your mobile number and click "Validate & Generate OTP" to receive your OTP.'
  });
  platformRegistry.register({
    id: "GOOGLE_ADS",
    name: "Google Ads",
    domains: ["ads.google.com", "accounts.google.com"],
    login: {
      url: "https://ads.google.com/",
      usernameSelector: 'input[type="email"], input[name="identifier"], input#identifierId'
      // Deliberately omitting passwordSelector to respect the frozen architecture
      // and prevent breaking on Google's two-step flow and passkey mandates.
    },
    manualStepMessage: 'Email filled. Google requires manual sign-in due to passkey / 2FA / account chooser. Click "Next" and continue manually.'
  });

  // src/content/capability-enforcer.ts
  function sendMessage(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (response) => {
        resolve(response || { success: false, error: "No response from background" });
      });
    });
  }
  if (!window.__WITHUS_ENFORCER_LOADED__) {
    window.__WITHUS_ENFORCER_LOADED__ = true;
    initEnforcer();
  }
  var WITHUS_CACHE_KEY = "withus_cap_cache_v1";
  function injectCSS(config, restrictions) {
    if (!config)
      return;
    const styleId = "withus-capability-enforcer-css";
    const stylesToInject = [];
    for (const cap of restrictions) {
      const rule = config.capabilityRestrictions?.[cap];
      if (rule?.hideElementsCSS)
        stylesToInject.push(...rule.hideElementsCSS);
    }
    if (stylesToInject.length === 0)
      return;
    let styleEl = document.getElementById(styleId);
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = styleId;
      document.documentElement.appendChild(styleEl);
    }
    styleEl.textContent = stylesToInject.map((sel) => `${sel} { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; }`).join("\n");
  }
  async function initEnforcer() {
    const config = platformRegistry.getForHost(location.hostname);
    if (!config || !config.capabilityRestrictions) {
      return;
    }
    try {
      const cached = await chrome.storage.session.get(WITHUS_CACHE_KEY);
      const cachedRestrictions = cached[WITHUS_CACHE_KEY];
      if (cachedRestrictions && cachedRestrictions.length > 0) {
        injectCSS(config, cachedRestrictions);
      }
    } catch (_) {
    }
    const response = await sendMessage({
      type: "GET_ACTIVE_SESSION",
      payload: { domain: location.hostname }
    });
    if (!response.success || !response.data?.sessions.length) {
      chrome.storage.session.remove(WITHUS_CACHE_KEY).catch(() => {
      });
      document.getElementById("withus-capability-enforcer-css")?.remove();
      return;
    }
    const session = response.data.sessions[0];
    let restrictionsToApply = [];
    if (config.id === "MCA") {
      let mcaRestricted = session.mcaRestrictedModules;
      if (!mcaRestricted && Array.isArray(session.capabilities)) {
        const MCA_TOP_LEVEL_MODULES = ["mca.master_data", "mca.llp_efiling", "mca.fo_services", "mca.dsc_services", "mca.company_efiling", "mca.complaints", "mca.document_related_services", "mca.payment_services", "mca.id_databank"];
        mcaRestricted = MCA_TOP_LEVEL_MODULES.filter((mod) => !session.capabilities.includes(mod));
      }
      if (!mcaRestricted || mcaRestricted.length === 0) {
        chrome.storage.session.remove(WITHUS_CACHE_KEY).catch(() => {
        });
        document.getElementById("withus-capability-enforcer-css")?.remove();
        return;
      }
      restrictionsToApply = mcaRestricted;
    } else {
      if (!session.capabilities || session.capabilities.length === 0) {
        return;
      }
      restrictionsToApply = session.capabilities;
    }
    chrome.storage.session.set({ [WITHUS_CACHE_KEY]: restrictionsToApply }).catch(() => {
    });
    const stylesToInject = [];
    const restrictedRoutes = [];
    const allowedRoutes = [];
    for (const cap of restrictionsToApply) {
      const restriction = config.capabilityRestrictions[cap];
      if (restriction) {
        if (restriction.hideElementsCSS) {
          stylesToInject.push(...restriction.hideElementsCSS);
        }
        if (restriction.restrictedRoutePatterns) {
          restrictedRoutes.push(...restriction.restrictedRoutePatterns);
        }
        if (restriction.allowedRoutePatterns) {
          allowedRoutes.push(...restriction.allowedRoutePatterns);
        }
      }
    }
    if (stylesToInject.length === 0 && restrictedRoutes.length === 0) {
      return;
    }
    if (stylesToInject.length > 0) {
      injectCSS(config, restrictionsToApply);
    }
    if (restrictedRoutes.length > 0 || allowedRoutes.length > 0) {
      enforceRoute(location.href, restrictedRoutes, allowedRoutes);
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;
      history.pushState = function(...args) {
        const url = args[2];
        if (url && typeof url === "string") {
          const fullUrl = new URL(url, location.origin).href;
          if (isRouteRestricted(fullUrl, restrictedRoutes, allowedRoutes)) {
            showRestrictedToast();
            return;
          }
        }
        return originalPushState.apply(this, args);
      };
      history.replaceState = function(...args) {
        const url = args[2];
        if (url && typeof url === "string") {
          const fullUrl = new URL(url, location.origin).href;
          if (isRouteRestricted(fullUrl, restrictedRoutes, allowedRoutes)) {
            showRestrictedToast();
            return;
          }
        }
        return originalReplaceState.apply(this, args);
      };
      window.addEventListener("popstate", () => {
        enforceRoute(location.href, restrictedRoutes, allowedRoutes);
      });
    }
  }
  function isRouteRestricted(urlStr, restricted, allowed) {
    try {
      const url = new URL(urlStr, location.origin);
      const pathAndHash = url.pathname + url.hash;
      for (const pattern of restricted) {
        if (pathAndHash.includes(pattern)) {
          return true;
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }
  function enforceRoute(urlStr, restricted, allowed) {
    if (isRouteRestricted(urlStr, restricted, allowed)) {
      showRestrictedToast();
      const safeRoute = allowed.length > 0 ? allowed[0] : "/";
      location.replace(safeRoute);
    }
  }
  function showRestrictedToast() {
    let toast = document.getElementById("withus-restriction-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "withus-restriction-toast";
      toast.style.cssText = [
        "position:fixed",
        "top:24px",
        "right:24px",
        "z-index:2147483647",
        "background:#dc3545",
        "color:#ffffff",
        "border-radius:8px",
        "padding:12px 20px",
        "font-family:system-ui,sans-serif",
        "font-size:14px",
        "font-weight:600",
        "box-shadow:0 10px 40px rgba(0,0,0,0.5)",
        "transition:opacity 0.3s ease",
        "pointer-events:none"
      ].join(";");
      toast.textContent = "Access Restricted by Administrator";
      document.body.appendChild(toast);
    }
    toast.style.opacity = "1";
    setTimeout(() => {
      toast.style.opacity = "0";
    }, 3e3);
  }
})();
