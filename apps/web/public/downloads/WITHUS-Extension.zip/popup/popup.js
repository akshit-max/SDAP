"use strict";
(() => {
  // src/lib/storage.ts
  var AUTH_KEY = "withus_auth";
  var PRESENCE_TABS_KEY = "withus_presence_tabs";
  var Storage = {
    async getAuth() {
      const result = await chrome.storage.local.get(AUTH_KEY);
      return result[AUTH_KEY] ?? null;
    },
    async setAuth(auth) {
      await chrome.storage.local.set({ [AUTH_KEY]: auth });
    },
    async clearAuth() {
      await chrome.storage.local.remove(AUTH_KEY);
    },
    async isAuthenticated() {
      const auth = await Storage.getAuth();
      if (!auth)
        return false;
      return Date.now() < auth.expiresAt - 6e4;
    },
    // ─── Presence (tab-keyed map) ─────────────────────────────────────────────
    // Persisted across service-worker terminations (Chrome MV3 ephemeral workers).
    // One entry per tab — tab IDs are numbers, stored as string keys.
    async _getPresenceTabs() {
      const result = await chrome.storage.local.get(PRESENCE_TABS_KEY);
      return result[PRESENCE_TABS_KEY] ?? {};
    },
    /**
     * Register that a specific tab is active on a platform.
     * Called from service worker PLATFORM_ACTIVE handler (with sender.tab.id).
     */
    async setTabPresence(tabId, entry) {
      const tabs = await Storage._getPresenceTabs();
      tabs[String(tabId)] = entry;
      await chrome.storage.local.set({ [PRESENCE_TABS_KEY]: tabs });
    },
    /**
     * Remove a tab's presence entry.
     * Called when a tab closes (chrome.tabs.onRemoved) or navigates away (PLATFORM_GONE).
     */
    async clearTabPresence(tabId) {
      const tabs = await Storage._getPresenceTabs();
      if (!tabs[String(tabId)])
        return;
      delete tabs[String(tabId)];
      if (Object.keys(tabs).length === 0) {
        await chrome.storage.local.remove(PRESENCE_TABS_KEY);
      } else {
        await chrome.storage.local.set({ [PRESENCE_TABS_KEY]: tabs });
      }
    },
    /**
     * Returns all currently tracked active tabs.
     * Empty object → no active platform tabs → heartbeat should not fire.
     */
    async getActiveTabs() {
      return Storage._getPresenceTabs();
    }
  };

  // src/lib/api.ts
  var BASE_URL = ("http://127.0.0.1:4000/api/v1" ? "http://127.0.0.1:4000/api/v1" : null) ?? "http://127.0.0.1:4000/api/v1";
  async function request(method, path, body, token) {
    const headers = {
      "Content-Type": "application/json",
      "X-Extension-Client": "withus-mv3"
    };
    if (token)
      headers["Authorization"] = `Bearer ${token}`;
    const res = await fetch(`${BASE_URL}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : void 0
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    return res.json();
  }
  var WithusApi = {
    // ─── Auth ──────────────────────────────────────────────────────────────────
    async login(email, password) {
      const res = await request("POST", "/auth/login", { email, password });
      return {
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
        userId: res.user.id,
        email: res.user.email,
        expiresAt: Date.now() + 60 * 60 * 1e3
      };
    },
    async refresh(refreshToken) {
      const auth = await Storage.getAuth();
      const res = await request("POST", "/auth/refresh", { refreshToken });
      return {
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
        userId: res.user?.id || auth?.userId || "",
        email: res.user?.email || auth?.email || "",
        expiresAt: Date.now() + 60 * 60 * 1e3
      };
    },
    async logout(refreshToken) {
      await request("POST", "/auth/logout", { refreshToken });
    },
    // ─── Me / Org ──────────────────────────────────────────────────────────────
    async getMe(token) {
      return request("GET", "/users/me", void 0, token);
    },
    // ─── Sessions ─────────────────────────────────────────────────────────────
    async getIncomingSessions(orgId, token) {
      return request("GET", `/organizations/${orgId}/sessions/incoming`, void 0, token);
    },
    // ─── Launch Session (Extension) ───────────────────────────────────────────
    async launchSession(orgId, sessionId, reason, token) {
      return request("POST", `/organizations/${orgId}/sessions/${sessionId}/reveal`, { reason }, token);
    },
    // ─── OTP Fetch ────────────────────────────────────────────────────────────
    /**
     * Requests the latest OTP from the grantor's Gmail inbox.
     * Returns only { otp: string } — no email content ever crosses this boundary.
     *
     * OTP Boundary Rule: this is the only place in the extension that calls /otp.
     * The content script receives only the extracted code string.
     */
    async fetchOtp(orgId, sessionId, token, platform, loginStartTime) {
      return request("POST", `/organizations/${orgId}/sessions/${sessionId}/otp`, { platform, loginStartTime }, token);
    },
    // ─── Presence Heartbeat ───────────────────────────────────────────────────
    /**
     * Report that the user is active on a given platform.
     *
     * This is fire-and-forget — the server always returns 204, and any network
     * or auth error is intentionally silenced. Heartbeat failures must never
     * interrupt autofill, session handling, or any other extension flow.
     *
     * The server validates that the user has an active authorized session for
     * the reported platform before recording the heartbeat.
     */
    async heartbeat(orgId, platform, token) {
      try {
        await request("POST", `/organizations/${orgId}/presence/heartbeat`, { platform }, token);
      } catch {
      }
    }
  };

  // src/popup/popup.ts
  var loginView = document.getElementById("login-view");
  var sessionsView = document.getElementById("sessions-view");
  var footer = document.getElementById("footer");
  var statusDot = document.getElementById("status-dot");
  var emailInput = document.getElementById("email");
  var passwordInput = document.getElementById("password");
  var loginBtn = document.getElementById("login-btn");
  var loginError = document.getElementById("login-error");
  var sessionsList = document.getElementById("sessions-list");
  var currentSiteEl = document.getElementById("current-site");
  var userEmailEl = document.getElementById("user-email");
  var logoutBtn = document.getElementById("logout-btn");
  async function init() {
    const authResponse = await sendMessage({ type: "CHECK_AUTH" });
    if (!authResponse.success) {
      showLogin();
      return;
    }
    const auth = await Storage.getAuth();
    userEmailEl.textContent = auth?.email || "";
    statusDot.classList.add("connected");
    await showSessions(auth?.email || "");
  }
  function showLogin() {
    loginView.classList.remove("hidden");
    sessionsView.classList.add("hidden");
    footer.classList.add("hidden");
    statusDot.classList.remove("connected");
  }
  loginBtn.addEventListener("click", async () => {
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    if (!email || !password) {
      showLoginError("Please enter your email and password.");
      return;
    }
    loginBtn.disabled = true;
    loginBtn.innerHTML = '<span class="spinner">\u27F3</span> Signing in\u2026';
    loginError.classList.add("hidden");
    try {
      const auth = await WithusApi.login(email, password);
      await Storage.setAuth(auth);
      userEmailEl.textContent = auth.email;
      statusDot.classList.add("connected");
      loginView.classList.add("hidden");
      await showSessions(auth.email);
    } catch (err) {
      showLoginError(err.message || "Login failed. Check your credentials.");
    } finally {
      loginBtn.disabled = false;
      loginBtn.textContent = "Sign in to WithUs";
    }
  });
  passwordInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter")
      loginBtn.click();
  });
  function showLoginError(msg) {
    loginError.textContent = msg;
    loginError.classList.remove("hidden");
  }
  async function showSessions(email) {
    sessionsView.classList.remove("hidden");
    footer.classList.remove("hidden");
    userEmailEl.textContent = email;
    sessionsList.innerHTML = '<div class="no-sessions"><strong>Loading\u2026</strong></div>';
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const hostname = tab?.url ? new URL(tab.url).hostname : "";
    if (hostname) {
      currentSiteEl.innerHTML = `Current site: <span>${hostname}</span>`;
    }
    const response = await sendMessage({
      type: "GET_ACTIVE_SESSION",
      payload: { domain: hostname }
    });
    if (!response.success) {
      sessionsList.innerHTML = `
      <div class="no-sessions">
        <strong>Not authenticated</strong>
        Please sign in to WithUs to view delegated sessions.
      </div>`;
      showLogin();
      return;
    }
    const sessions = response.data?.sessions || [];
    const orgId = response.data?.orgId || "";
    if (sessions.length === 0) {
      sessionsList.innerHTML = `
      <div class="no-sessions">
        <strong>No active sessions for this site</strong>
        Ask an admin to grant you a delegated session for this platform.
      </div>`;
      return;
    }
    renderSessions(sessions, orgId, tab?.id);
  }
  function renderSessions(sessions, orgId, tabId) {
    sessionsList.innerHTML = "";
    for (const session of sessions) {
      const card = document.createElement("div");
      card.className = "session-card";
      const expiresAt = new Date(session.expiresAt).toLocaleString();
      const revealsLeft = session.maxReveals ? `${session.maxReveals - session.revealCount} reveals left` : "Unlimited reveals";
      card.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between">
        <span class="session-name">${escapeHtml(session.resourceName || "Unknown")}</span>
        <span class="badge-active">Active</span>
      </div>
      <div class="session-meta">
        <span>Granted by ${escapeHtml(session.grantor?.email || "Unknown")}</span>
        <span>${revealsLeft}</span>
      </div>
      <div class="session-meta">Expires ${expiresAt}</div>
      <button class="btn btn-primary" style="margin-top:10px" 
              data-session-id="${session.id}" 
              data-org-id="${session.__orgId || orgId}"
              data-tab-id="${tabId}">
        Autofill this page
      </button>
    `;
      sessionsList.appendChild(card);
    }
    sessionsList.querySelectorAll("[data-session-id]").forEach((btn) => {
      btn.addEventListener("click", () => handleAutofill(btn, tabId));
    });
  }
  async function handleAutofill(btn, tabId) {
    const sessionId = btn.dataset.sessionId;
    const orgId = btn.dataset.orgId;
    btn.disabled = true;
    btn.textContent = "Filling\u2026";
    if (tabId) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: triggerAutofill,
          args: [sessionId, orgId]
        });
        btn.textContent = "\u2713 Filled";
        setTimeout(() => window.close(), 1200);
      } catch {
        btn.textContent = "Fill failed \u2014 try on the page";
        btn.disabled = false;
      }
    } else {
      btn.textContent = "No active tab";
      btn.disabled = false;
    }
  }
  function triggerAutofill(sessionId, orgId) {
    window.dispatchEvent(
      new CustomEvent("withus:autofill", { detail: { sessionId, orgId } })
    );
  }
  logoutBtn.addEventListener("click", async () => {
    logoutBtn.textContent = "Signing out\u2026";
    await sendMessage({ type: "LOGOUT" });
    showLogin();
    sessionsList.innerHTML = "";
    statusDot.classList.remove("connected");
    logoutBtn.textContent = "Sign out";
  });
  function sendMessage(msg) {
    return chrome.runtime.sendMessage(msg);
  }
  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  init().catch(console.error);
})();
