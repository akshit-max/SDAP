"use strict";
(() => {
  // src/lib/storage.ts
  var AUTH_KEY = "withus_auth";
  var PRESENCE_TABS_KEY = "withus_presence_tabs";
  var Storage = {
    async getAuth() {
      const result = await chrome.storage.local.get(AUTH_KEY);
      return result[AUTH_KEY] ?? null;
    },
    async setAuth(auth) {
      await chrome.storage.local.set({ [AUTH_KEY]: auth });
    },
    async clearAuth() {
      await chrome.storage.local.remove(AUTH_KEY);
    },
    async isAuthenticated() {
      const auth = await Storage.getAuth();
      if (!auth)
        return false;
      return Date.now() < auth.expiresAt - 6e4;
    },
    // ─── Presence (tab-keyed map) ─────────────────────────────────────────────
    // Persisted across service-worker terminations (Chrome MV3 ephemeral workers).
    // One entry per tab — tab IDs are numbers, stored as string keys.
    async _getPresenceTabs() {
      const result = await chrome.storage.local.get(PRESENCE_TABS_KEY);
      return result[PRESENCE_TABS_KEY] ?? {};
    },
    /**
     * Register that a specific tab is active on a platform.
     * Called from service worker PLATFORM_ACTIVE handler (with sender.tab.id).
     */
    async setTabPresence(tabId, entry) {
      const tabs = await Storage._getPresenceTabs();
      tabs[String(tabId)] = entry;
      await chrome.storage.local.set({ [PRESENCE_TABS_KEY]: tabs });
    },
    /**
     * Remove a tab's presence entry.
     * Called when a tab closes (chrome.tabs.onRemoved) or navigates away (PLATFORM_GONE).
     */
    async clearTabPresence(tabId) {
      const tabs = await Storage._getPresenceTabs();
      if (!tabs[String(tabId)])
        return;
      delete tabs[String(tabId)];
      if (Object.keys(tabs).length === 0) {
        await chrome.storage.local.remove(PRESENCE_TABS_KEY);
      } else {
        await chrome.storage.local.set({ [PRESENCE_TABS_KEY]: tabs });
      }
    },
    /**
     * Returns all currently tracked active tabs.
     * Empty object → no active platform tabs → heartbeat should not fire.
     */
    async getActiveTabs() {
      return Storage._getPresenceTabs();
    }
  };

  // src/lib/api.ts
  var BASE_URL = ("https://withus-yy5i.onrender.com/api/v1" ? "https://withus-yy5i.onrender.com/api/v1" : null) ?? "http://127.0.0.1:4000/api/v1";
  async function request(method, path, body, token) {
    const headers = {
      "Content-Type": "application/json",
      "X-Extension-Client": "withus-mv3"
    };
    if (token)
      headers["Authorization"] = `Bearer ${token}`;
    const res = await fetch(`${BASE_URL}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : void 0
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    return res.json();
  }
  var WithusApi = {
    // ─── Auth ──────────────────────────────────────────────────────────────────
    async login(email, password) {
      const res = await request("POST", "/auth/login", { email, password });
      return {
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
        userId: res.user.id,
        email: res.user.email,
        expiresAt: Date.now() + 60 * 60 * 1e3
      };
    },
    async refresh(refreshToken) {
      const auth = await Storage.getAuth();
      const res = await request("POST", "/auth/refresh", { refreshToken });
      return {
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
        userId: res.user?.id || auth?.userId || "",
        email: res.user?.email || auth?.email || "",
        expiresAt: Date.now() + 60 * 60 * 1e3
      };
    },
    async logout(refreshToken) {
      await request("POST", "/auth/logout", { refreshToken });
    },
    // ─── Me / Org ──────────────────────────────────────────────────────────────
    async getMe(token) {
      return request("GET", "/users/me", void 0, token);
    },
    // ─── Sessions ─────────────────────────────────────────────────────────────
    async getIncomingSessions(orgId, token) {
      return request("GET", `/organizations/${orgId}/sessions/incoming`, void 0, token);
    },
    // ─── Launch Session (Extension) ───────────────────────────────────────────
    // Uses the dedicated /launch endpoint which:
    //   - Accepts both EXTENSION and REVEAL sessions (autofill is allowed for both)
    //   - Does NOT require permission === REVEAL (that check is for web portal /reveal only)
    //   - Still enforces: granteeId, status=ACTIVE, expiry, maxReveals
    async launchSession(orgId, sessionId, reason, token) {
      return request("POST", `/organizations/${orgId}/sessions/${sessionId}/launch`, { reason }, token);
    },
    // ─── OTP Fetch ────────────────────────────────────────────────────────────
    /**
     * Requests the latest OTP from the grantor's Gmail inbox.
     * Returns only { otp: string } — no email content ever crosses this boundary.
     *
     * OTP Boundary Rule: this is the only place in the extension that calls /otp.
     * The content script receives only the extracted code string.
     */
    async fetchOtp(orgId, sessionId, token, platform, loginStartTime) {
      return request("POST", `/organizations/${orgId}/sessions/${sessionId}/otp`, { platform, loginStartTime }, token);
    },
    // ─── Presence Heartbeat ───────────────────────────────────────────────────
    /**
     * Report that the user is active on a given platform.
     *
     * This is fire-and-forget — the server always returns 204, and any network
     * or auth error is intentionally silenced. Heartbeat failures must never
     * interrupt autofill, session handling, or any other extension flow.
     *
     * The server validates that the user has an active authorized session for
     * the reported platform before recording the heartbeat.
     */
    async heartbeat(orgId, platform, token) {
      try {
        await request("POST", `/organizations/${orgId}/presence/heartbeat`, { platform }, token);
      } catch {
      }
    }
  };

  // src/providers/platform-registry.ts
  var PlatformRegistry = class {
    constructor() {
      this.configs = /* @__PURE__ */ new Map();
    }
    register(config) {
      this.configs.set(config.id, config);
    }
    getForHost(hostname) {
      for (const config of this.configs.values()) {
        for (const domain of config.domains) {
          if (hostname === domain || hostname.endsWith(`.${domain}`)) {
            return config;
          }
        }
      }
      return null;
    }
    getAll() {
      return Array.from(this.configs.values());
    }
  };
  var platformRegistry = new PlatformRegistry();
  platformRegistry.register({
    id: "GITHUB",
    name: "GitHub",
    domains: ["github.com"],
    login: {
      url: "https://github.com/login",
      usernameSelector: 'input[name="login"], input#login_field',
      passwordSelector: 'input[name="password"], input#password',
      submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
    },
    principalType: "GITHUB_USERNAME",
    supportsDelegation: true,
    /**
     * Module-level UI restrictions for GitHub.
     *
     * GitHub's repository navigation uses stable data-tab-item attributes
     * that have been consistent across GitHub's design iterations.
     * These are confirmed from the live GitHub repository <nav> outerHTML.
     *
     * Selector strategy:
     *   a[data-tab-item="..."] — direct attribute match on the nav anchor.
     *   These are semantic, non-generated attributes and extremely stable.
     *
     * Scope: Repository-level navigation only (the top tab bar on repo pages).
     * Organisation-level restrictions (People, Org Settings, etc.) require
     * separate outerHTML inspection and will be added as a second step.
     */
    capabilityRestrictions: {
      "github.repo_actions": {
        hideElementsCSS: ['a[data-tab-item="actions"]']
      },
      "github.repo_projects": {
        hideElementsCSS: ['a[data-tab-item="projects"]:not([href^="/orgs/"])']
      },
      "github.repo_security": {
        hideElementsCSS: ['a[data-tab-item="security-and-quality"]']
      },
      "github.repo_wiki": {
        hideElementsCSS: ['a[data-tab-item="wiki"]']
      },
      "github.repo_insights": {
        hideElementsCSS: ['a[data-tab-item="insights"]']
      },
      "github.repo_settings": {
        hideElementsCSS: ['a[data-tab-item="settings"]']
      },
      "github.org_members": {
        hideElementsCSS: ['a[data-tab-item="people"]']
      },
      "github.org_projects": {
        hideElementsCSS: ['a[data-tab-item="projects"][href^="/orgs/"]']
      }
    }
  });
  platformRegistry.register({
    id: "VERCEL",
    name: "Vercel",
    domains: ["vercel.com"],
    login: {
      url: "https://vercel.com/login",
      usernameSelector: 'input[type="email"], input[name="email"]',
      passwordSelector: 'input[type="password"], input[name="password"]',
      submitSelector: 'button[type="submit"]'
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[autocomplete="one-time-code"], input[inputmode="numeric"], input[type="number"], input[name="code"], input[type="text"][maxlength="1"]'
    },
    principalType: "EMAIL",
    supportsDelegation: true,
    capabilityRestrictions: {
      "vercel.domains": {
        hideElementsCSS: ['a[data-sidebar-link-key="Domains"]']
      },
      "vercel.analytics": {
        hideElementsCSS: ['a[data-sidebar-link-key="Analytics"]']
      },
      "vercel.env": {
        hideElementsCSS: ['a[data-sidebar-link-key="Environment Variables"]']
      },
      "vercel.storage": {
        hideElementsCSS: ['a[data-sidebar-link-key="Storage"]']
      },
      "vercel.integrations": {
        hideElementsCSS: ['a[data-sidebar-link-key="Integrations"]']
      },
      "vercel.settings": {
        hideElementsCSS: ['a[data-sidebar-link-key="Settings"]']
      }
    }
  });
  platformRegistry.register({
    id: "GODADDY",
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    login: {
      url: "https://sso.godaddy.com/",
      usernameSelector: '#username, input[name="username"], input[type="email"]',
      passwordSelector: '#password, input[name="password"], input[type="password"]',
      submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]',
      requirePasswordOnDOM: true
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[aria-label="Hide password" i]',
      "#password",
      "div:has(> input#password)"
    ],
    principalType: "EMAIL",
    supportsDelegation: true,
    capabilityRestrictions: {
      "godaddy.domain": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/domain.menu_item.click"]']
      },
      "godaddy.website": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/website.menu_item.click"]']
      },
      "godaddy.email": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/email.menu_item.click"]']
      },
      "godaddy.store": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/store.menu_item.click"]']
      },
      "godaddy.appointments": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/appointments.menu_item.click"]']
      },
      "godaddy.marketing": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/marketing.menu_item.click"]']
      },
      "godaddy.conversations": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/conversations.menu_item.click"]']
      },
      "godaddy.customers": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/customers.menu_item.click"]']
      },
      "godaddy.deals": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/deals.menu_item.click"]']
      },
      "godaddy.users": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/users.menu_item.click"]']
      },
      "godaddy.app_switcher": {
        hideElementsCSS: ['[data-testid="app-switcher-btn"]']
      },
      "godaddy.my_products": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/my_products.menu_item.click"]']
      },
      "godaddy.account_settings": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/account_settings.menu_item.click"]']
      },
      "godaddy.billing": {
        hideElementsCSS: ['[data-eid*="billing.menu_item"], a[href*="billing"]']
      },
      "godaddy.shop": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/shop_godaddycom.menu_item.click"]']
      }
    }
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com", "www.linkedin.com"],
    login: {
      url: "https://www.linkedin.com/checkpoint/lg/login?trk=hb_signin",
      usernameSelector: 'input[name="session_key"], #session_key, input[autocomplete="username"], input[autocomplete="email"], input[type="email"], #username',
      passwordSelector: 'input[name="session_password"], #session_password, input[autocomplete="current-password"], input[type="password"], #password',
      submitSelector: 'button[type="submit"], button[aria-label="Sign in"], .login__form_action_container button'
    }
  });
  platformRegistry.register({
    id: "SHOPIFY",
    name: "Shopify",
    domains: ["shopify.com", "accounts.shopify.com", "admin.shopify.com"],
    login: {
      url: "https://admin.shopify.com/login",
      usernameSelector: 'input[type="email"], input[autocomplete="username"], #account_email',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], #account_password',
      submitSelector: 'button[type="submit"], button[name="commit"]'
    },
    hideElementsCSS: [
      "button.js-password-button",
      'button[aria-controls="account_password"]',
      "#account_password",
      ".password-wrapper:has(#account_password)"
    ],
    capabilityRestrictions: {
      "shopify.orders": {
        hideElementsCSS: ['a[href$="/orders"]']
      },
      "shopify.products": {
        hideElementsCSS: ['a[href$="/products"]']
      },
      "shopify.customers": {
        hideElementsCSS: ['a[href$="/customers"]']
      },
      "shopify.growth": {
        hideElementsCSS: ['a[href$="/growth"]']
      },
      "shopify.discounts": {
        hideElementsCSS: ['a[href$="/discounts"]']
      },
      "shopify.content": {
        hideElementsCSS: ['a[href*="/content"]']
      },
      "shopify.markets": {
        hideElementsCSS: ['a[href$="/markets"]']
      },
      "shopify.analytics": {
        hideElementsCSS: ['a[href$="/analytics"]']
      },
      "shopify.sales_channels": {
        hideElementsCSS: ['a[href*="/themes"]', 'a[href*="/pages"]', 'a[href*="/blogs"]', 'a[href*="/menus"]', 'a[href*="/preferences"]']
      },
      "shopify.apps": {
        hideElementsCSS: ['a[href*="/apps/"]']
      },
      "shopify.settings": {
        hideElementsCSS: ['a[href$="/settings"]']
      }
    }
  });
  platformRegistry.register({
    id: "STRIPE",
    name: "Stripe",
    domains: ["stripe.com", "dashboard.stripe.com"],
    login: {
      url: "https://dashboard.stripe.com/login",
      usernameSelector: 'input[type="email"], input[name="email"], input[autocomplete="username"]',
      passwordSelector: 'input[type="password"], input[name="password"], input[autocomplete="current-password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-testid="login-button"]'
    },
    hideElementsCSS: [
      'input[data-testid="login-password-input"]',
      "#old-password",
      'div:has(> input[data-testid="login-password-input"])',
      "div:has(> input#old-password)"
    ],
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[name="verification_code"]',
      submitSelector: 'button[type="submit"]'
    },
    capabilityRestrictions: {
      "stripe.payments": {
        hideElementsCSS: ['li[data-testid="core-nav-item-payments"]', 'a[data-testid="toggle-workload-payments"]']
      },
      "stripe.customers": {
        hideElementsCSS: ['li[data-testid="core-nav-item-customers"]']
      },
      "stripe.products": {
        hideElementsCSS: ['li[data-testid="core-nav-item-products"]']
      },
      "stripe.balance": {
        hideElementsCSS: ['li[data-testid="core-nav-item-balances"]']
      },
      "stripe.billing": {
        hideElementsCSS: ['a[data-testid="toggle-workload-billing"]']
      },
      "stripe.reports": {
        hideElementsCSS: ['a[data-testid="toggle-workload-reporting"]']
      },
      "stripe.developers": {
        hideElementsCSS: ["section#developer-nav"]
      }
    }
  });
  platformRegistry.register({
    id: "RAZORPAY",
    name: "Razorpay",
    // Only accounts.razorpay.com is the login/auth subdomain.
    // dashboard.razorpay.com is the post-login dashboard, required here so capability enforcer runs on it.
    domains: ["accounts.razorpay.com", "dashboard.razorpay.com"],
    login: {
      url: "https://accounts.razorpay.com/auth",
      usernameSelector: 'input[type="email"], input[type="text"], input[type="tel"], input[autocomplete="username"], input[autocomplete="email"]',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], input[placeholder*="password" i]',
      submitSelector: 'button[type="submit"], button#btn-login, #btn-login, button.btn-primary, button[data-testid="btn-submit"]'
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[data-blade-component="icon-button"] svg'
    ],
    capabilityRestrictions: {
      "razorpay.transactions": { hideElementsCSS: ['a[href="/app/payments"]'] },
      "razorpay.settlements": { hideElementsCSS: ['a[href="/app/settlements"]'] },
      "razorpay.reports": { hideElementsCSS: ['a[href="/app/reports"]'] },
      "razorpay.payment_links": { hideElementsCSS: ['a[href="/app/paymentlinks"]'] },
      "razorpay.payment_pages": { hideElementsCSS: ['a[href="/app/paymentpages"]'] },
      "razorpay.invoices": { hideElementsCSS: ['a[href="/app/invoices"]'] },
      "razorpay.payment_button": { hideElementsCSS: ['a[href="/app/paymentbuttons"]'] },
      "razorpay.subscriptions": { hideElementsCSS: ['a[href="/app/subscriptions"]'] },
      "razorpay.smart_collect": { hideElementsCSS: ['a[href="/app/smartcollect/virtualaccounts"]'] },
      "razorpay.optimizer": { hideElementsCSS: ['a[href="/app/optimizer"]'] },
      "razorpay.account_settings": { hideElementsCSS: ['a[href="/app/account-settings"]'] }
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[inputmode="numeric"][maxlength="1"], input[type="number"][maxlength="1"]',
      // Specific selectors first. button[type="submit"] is the safe fallback since
      // after all 6 digits are filled, the only submit-type button on this page is Verify.
      // We deliberately removed button:not([disabled]) as it matched Resend/Back first.
      submitSelector: 'button[data-testid="btn-verify"], button[data-testid="verify-btn"], button[type="submit"]'
    }
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com"],
    login: {
      url: "https://www.linkedin.com/login",
      usernameSelector: 'input[name="session_key"], input#username, input[type="text"]:not([placeholder*="Search" i]):not(.search-global-typeahead__input), input[type="email"]',
      passwordSelector: 'input[name="session_password"], input#password, input[type="password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-litms-control-urn="login-submit"]'
    },
    hideElementsCSS: [
      'input[type="password"][autocomplete="current-password"]',
      'button[aria-label="Show password" i]',
      "button:has(svg#visibility-small)",
      'div:has(> input[type="password"][autocomplete="current-password"])'
    ],
    capabilityRestrictions: {
      "linkedin.my_network": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/mynetwork"]']
      },
      "linkedin.jobs": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/jobs"]']
        // Inferred from pattern
      },
      "linkedin.messaging": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/messaging"]']
      },
      "linkedin.notifications": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/notifications"]']
      },
      "linkedin.page_dashboard": {
        hideElementsCSS: ['[data-test-org-menu-item="HOME"]']
      },
      "linkedin.page_posts": {
        hideElementsCSS: ['[data-test-org-menu-item="POSTS"]']
      },
      "linkedin.page_analytics": {
        hideElementsCSS: ['[data-test-org-menu-item="ANALYTICS"]']
      },
      "linkedin.page_feed": {
        hideElementsCSS: ['[data-test-org-menu-item="FEED"]']
      },
      "linkedin.page_activity": {
        hideElementsCSS: ['[data-test-org-menu-item="ACTIVITY"]']
      },
      "linkedin.page_inbox": {
        hideElementsCSS: ['[data-test-org-menu-item="INBOX"]']
      },
      "linkedin.page_services": {
        hideElementsCSS: ['[data-test-org-menu-item="SERVICES"]']
      },
      "linkedin.page_posted_jobs": {
        hideElementsCSS: ['[data-test-org-menu-item="POSTED_JOBS"]']
      },
      "linkedin.page_edit": {
        hideElementsCSS: ['[data-test-org-menu-item="EDIT"]']
      },
      "linkedin.page_settings": {
        hideElementsCSS: ['[data-test-org-menu-item="SETTINGS"]']
      },
      "linkedin.page_advertise": {
        hideElementsCSS: ['[data-test-org-menu-item="ADVERTISE"]']
      }
    }
  });
  platformRegistry.register({
    id: "MCA",
    name: "MCA Portal",
    domains: ["www.mca.gov.in", "mca.gov.in"],
    login: {
      url: "https://www.mca.gov.in/content/mca/global/en/foportal/fologin.html",
      // User ID: accepts CIN/LLPIN/FCRN for companies or email for other users.
      // NOTE: input[type="text"] or form-based fallbacks are BANNED here.
      // The MCA header contains a search bar form that appears before the login
      // form in the DOM, so generic fallbacks will match the search bar.
      usernameSelector: [
        'input[name="userID" i]',
        // exact match from DOM (case-insensitive)
        'input[name="userId" i]',
        'input[name="loginid" i]',
        ".userID input",
        // wrapper class from DOM
        ".user-id-input input"
        // wrapper class from DOM
      ].join(", "),
      passwordSelector: [
        'input[type="password"]',
        'input[name="password"]',
        'input[id="password"]'
      ].join(", ")
      // No submitSelector — manualStepMessage prevents auto-submit
    },
    manualStepMessage: "WithUs Vault: Secure session activated. Please resolve the CAPTCHA to proceed.",
    capabilityRestrictions: {
      "mca.master_data": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/master-data.html"])'] },
      "mca.llp_efiling": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/llp-e-filling.html"])'] },
      "mca.fo_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/fo-llp-services.html"])'] },
      "mca.dsc_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/dsc-services-v3.html"])'] },
      "mca.company_efiling": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/e-filing.html"])'] },
      "mca.complaints": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/complaints.html"])'] },
      "mca.document_related_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/document-related-services.html"])'] },
      "mca.payment_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/fee-and-payment-services.html"])'] },
      "mca.id_databank": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/id-databank-services.html"])'] }
    }
  });
  platformRegistry.register({
    id: "GST",
    name: "GST Portal",
    domains: ["gst.gov.in", "services.gst.gov.in"],
    login: {
      url: "https://services.gst.gov.in/services/login",
      // Specific name/id selectors only Ã¢â‚¬â€ intentionally exclude input[type="text"]
      // to prevent matching the CAPTCHA field which is also type=text on this page.
      usernameSelector: [
        "#user_name",
        'input[name="user_name"]',
        'input[id="user_name"]',
        'input[name="username"]',
        'input[id="username"]'
      ].join(", "),
      passwordSelector: [
        "#user_pass",
        // Exact ID match based on DOM snippet
        'input[name="user_pass"]',
        // GST-specific: confirmed from portal DOM
        'input[id="user_pass"]',
        'input[type="password"]',
        // standard fallback
        'input[name="password"]'
      ].join(", ")
      // No submitSelector — manualStepMessage prevents auto-submit
    },
    capabilityRestrictions: {
      "gst.registration": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/registration"]']
      },
      "gst.ledgers": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/ledgers"]']
      },
      "gst.returns": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/returns"]']
      },
      "gst.payments": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/payments"]']
      },
      "gst.refunds": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/refunds"]']
      }
    },
    manualStepMessage: "Credentials filled. Please complete the CAPTCHA and OTP verification to continue."
  });
  platformRegistry.register({
    id: "UDYAM",
    name: "Udyam Portal",
    domains: ["udyamregistration.gov.in"],
    login: {
      url: "https://udyamregistration.gov.in",
      usernameSelector: [
        'input[name="udyam_no"]',
        'input[id="udyam_no"]',
        'input[name="Udyam_No"]',
        'input[name="udyamNo"]',
        'input[placeholder*="Udyam" i]',
        'input[placeholder*="Registration Number" i]',
        'input[maxlength="19"]'
        // Registration numbers are exactly 19 chars
      ].join(", ")
      // No passwordSelector — mobile number is NOT represented here.
      // Architecture Preservation Directive: do not overload passwordSelector semantics.
    },
    manualStepMessage: 'Udyam Registration Number filled. Please enter your mobile number and click "Validate & Generate OTP" to receive your OTP.',
    capabilityRestrictions: {
      "udyam.cancellation": {
        hideElementsCSS: ['a[href="Udyam_Cancellation.aspx"]']
      },
      "udyam.print_certificate": {
        hideElementsCSS: ["#ctl00_ContentPlaceHolder1_btnPrintC"]
      },
      "udyam.edit_details": {
        hideElementsCSS: ["#ctl00_ContentPlaceHolder1_btnEdit"]
      }
    }
  });
  platformRegistry.register({
    id: "GMAIL",
    name: "Gmail",
    domains: ["mail.google.com", "accounts.google.com"],
    login: {
      url: "https://mail.google.com",
      usernameSelector: 'input#identifierId, input[name="identifier"], input[type="email"]',
      passwordSelector: 'input[name="Passwd"], input[name="password"], input[type="password"]',
      submitSelector: 'div#identifierNext button, div#passwordNext button, button[type="submit"]'
    },
    // Only hide the "Show password" row — never hide the actual password input.
    // Hiding input[type="password"] creates a black box (display:none kills the bullets).
    // Hiding div:has(> input[type="password"]) accidentally matches on page 1 too because
    // Google pre-renders a hidden password field in the DOM on the email step.
    //
    // Show password selectors confirmed from live DOM:
    //   div[jsname="wQNmvb"] — the entire "Show password" checkbox row (new Google UI)
    //   button[jsname="M1Kmfa"] — legacy eye-icon button (fallback for older Google UI)
    hideElementsCSS: [
      'div[jsname="wQNmvb"]',
      // "Show password" checkbox row — new Google UI
      'button[jsname="M1Kmfa"]'
      // "Show password" eye icon — legacy Google UI fallback
    ],
    // No manualStepMessage for Gmail.
    // Email and password are on two separate Google-hosted pages (hard navigations).
    // The content script auto-fills and auto-submits each step in sequence:
    //   Page 1 (identifier): fill email → click div#identifierNext button
    //   Page 2 (challenge):  fill password → click div#passwordNext button
    // If Google then shows 2-Step Verification, the user completes it manually.
    // Adding manualStepMessage would block auto-submit on BOTH steps, leaving the
    // member stuck with a filled-but-unsubmitted form — worse UX than letting it flow.
    capabilityRestrictions: {
      "gmail.compose": {
        // Gmail Compose button — [gh="cm"] is the most stable attribute, but we also include 
        // class names and wrapper selectors to ensure the button and its container are fully hidden.
        hideElementsCSS: ['div[gh="cm"]', ".T-I-KE", 'div[jscontroller="eIu7Db"]', 'div:has(> div[gh="cm"])']
      },
      "gmail.inbox": {
        hideElementsCSS: ['a[href*="#inbox"]', 'div.aim:has(a[href*="#inbox"])']
      },
      "gmail.starred": {
        hideElementsCSS: ['a[href*="#starred"]', 'div.aim:has(a[href*="#starred"])']
      },
      "gmail.snoozed": {
        hideElementsCSS: ['a[href*="#snoozed"]', 'div.aim:has(a[href*="#snoozed"])']
      },
      "gmail.sent": {
        // Gmail sidebar Sent folder link.
        hideElementsCSS: ['a[href*="#sent"]', 'div.aim[data-tooltip*="Sent" i]', 'div.aim:has(a[href*="#sent"])']
      },
      "gmail.drafts": {
        hideElementsCSS: ['a[href*="#drafts"]', 'div.aim:has(a[href*="#drafts"])']
      },
      "gmail.purchases": {
        hideElementsCSS: ['a[href*="#category/purchases"]', 'div.aim:has(a[href*="#category/purchases"])']
      },
      "gmail.important": {
        hideElementsCSS: ['a[href*="#imp"]', 'div.aim:has(a[href*="#imp"])']
      },
      "gmail.scheduled": {
        hideElementsCSS: ['a[href*="#scheduled"]', 'div.aim:has(a[href*="#scheduled"])']
      },
      "gmail.all_mail": {
        hideElementsCSS: ['a[href*="#all"]', 'div.aim:has(a[href*="#all"])']
      },
      "gmail.spam": {
        hideElementsCSS: ['a[href*="#spam"]', 'div.aim:has(a[href*="#spam"])']
      },
      "gmail.trash": {
        // Gmail sidebar Trash/Bin folder link.
        hideElementsCSS: ['a[href*="#trash"]', 'div.aim[data-tooltip*="Trash" i]', 'div.aim[data-tooltip*="Bin" i]', 'div.aim:has(a[href*="#trash"])']
      },
      "gmail.labels": {
        // Label and subscription management menu in Gmail sidebar.
        hideElementsCSS: ['a[href*="#settings/labels"]', 'a[href*="#subscriptions"]', 'div.aim:has(a[href*="#settings/labels"])', 'div.aim:has(a[href*="#subscriptions"])']
      },
      "gmail.settings": {
        // Gmail settings gear icon (top-right of inbox).
        hideElementsCSS: ['div[data-tooltip*="Settings" i].FH', 'div[aria-label*="Settings" i].FH']
      },
      "gmail.contacts": {
        // Google Contacts link in Gmail's apps/sidebar.
        hideElementsCSS: ['a[href*="contacts.google.com"]']
      }
    }
  });
  platformRegistry.register({
    id: "GOOGLE_ADS",
    name: "Google Ads",
    domains: ["ads.google.com", "accounts.google.com"],
    login: {
      url: "https://ads.google.com/",
      usernameSelector: 'input[type="email"], input[name="identifier"], input#identifierId'
      // Deliberately omitting passwordSelector to respect the frozen architecture
      // and prevent breaking on Google's two-step flow and passkey mandates.
    },
    manualStepMessage: 'Email filled. Google requires manual sign-in due to passkey / 2FA / account chooser. Click "Next" and continue manually.'
  });

  // src/background/service-worker.ts
  chrome.alarms.create("token-refresh", { periodInMinutes: 50 });
  chrome.alarms.create("presence-heartbeat", { periodInMinutes: 0.5 });
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === "token-refresh") {
      const auth = await Storage.getAuth();
      if (!auth?.refreshToken)
        return;
      try {
        const fresh = await WithusApi.refresh(auth.refreshToken);
        await Storage.setAuth(fresh);
      } catch {
        await Storage.clearAuth();
      }
    }
    if (alarm.name === "presence-heartbeat") {
      const tabs = await Storage.getActiveTabs();
      const entries = Object.values(tabs);
      if (entries.length === 0)
        return;
      const auth = await Storage.getAuth();
      if (!auth)
        return;
      const seen = /* @__PURE__ */ new Set();
      const distinct = entries.filter(({ orgId, platform }) => {
        const key = `${orgId}::${platform}`;
        if (seen.has(key))
          return false;
        seen.add(key);
        return true;
      });
      await Promise.allSettled(
        distinct.map(
          ({ orgId, platform }) => WithusApi.heartbeat(orgId, platform, auth.accessToken)
        )
      );
    }
  });
  chrome.runtime.onInstalled.addListener(() => {
    if (chrome.privacy && chrome.privacy.services && chrome.privacy.services.passwordSavingEnabled) {
      chrome.privacy.services.passwordSavingEnabled.set({ value: false, scope: "regular" }).catch(() => {
      });
    }
  });
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      handleMessage(message, sender).then(sendResponse).catch((err) => sendResponse({ success: false, error: String(err?.message || err) }));
      return true;
    }
  );
  chrome.tabs.onRemoved.addListener((tabId) => {
    Storage.clearTabPresence(tabId).catch(() => {
    });
  });
  var _sessionCache = /* @__PURE__ */ new Map();
  var _inFlight = /* @__PURE__ */ new Map();
  async function handleMessage(msg, sender) {
    switch (msg.type) {
      case "CHECK_AUTH": {
        const auth = await Storage.getAuth();
        if (!auth)
          return { success: false, error: "NOT_AUTHENTICATED" };
        const isValid = await Storage.isAuthenticated();
        if (!isValid)
          return { success: false, error: "TOKEN_EXPIRED" };
        return { success: true, data: { email: auth.email } };
      }
      case "GET_ACTIVE_SESSION": {
        const { domain } = msg.payload;
        const hit = _sessionCache.get(domain);
        if (hit && Date.now() - hit.ts < 5e3) {
          return { success: true, data: hit.data };
        }
        const existing = _inFlight.get(domain);
        if (existing)
          return existing;
        const fetchPromise = (async () => {
          try {
            const auth = await Storage.getAuth();
            if (!auth)
              return { success: false, error: "NOT_AUTHENTICATED" };
            const me = await WithusApi.getMe(auth.accessToken);
            const memberships = me.organizationMemberships || [];
            if (memberships.length === 0)
              return { success: false, error: "NO_ORGANIZATION" };
            let allSessions = [];
            const hostname = domain.replace(/^www\./, "");
            await Promise.all(
              memberships.map(async (m) => {
                try {
                  const sessions = await WithusApi.getIncomingSessions(m.organizationId, auth.accessToken);
                  const matching = sessions.filter((s) => {
                    if (s.status !== "ACTIVE")
                      return false;
                    if (s.expiresAt && new Date(s.expiresAt) < /* @__PURE__ */ new Date())
                      return false;
                    const provider = s.integrationProvider;
                    if (provider) {
                      const config = platformRegistry.getForHost(hostname);
                      if (config && config.id === provider)
                        return true;
                    }
                    const name = s.resourceName?.toLowerCase() || "";
                    if (!name)
                      return false;
                    const GENERIC = /* @__PURE__ */ new Set(["gov", "com", "net", "org", "in", "co", "www", "app", "api"]);
                    const parts = hostname.split(".").filter((p) => p.length >= 3 && !GENERIC.has(p));
                    return parts.some((part) => name.includes(part) || part.includes(name));
                  }).map((s) => ({ ...s, __orgId: m.organizationId }));
                  allSessions = allSessions.concat(matching);
                } catch (_) {
                }
              })
            );
            const data = { sessions: allSessions, orgId: memberships[0].organizationId };
            _sessionCache.set(domain, { ts: Date.now(), data });
            return { success: true, data };
          } finally {
            _inFlight.delete(domain);
          }
        })();
        _inFlight.set(domain, fetchPromise);
        return fetchPromise;
      }
      case "LAUNCH_SESSION": {
        const { sessionId, orgId } = msg.payload;
        const auth = await Storage.getAuth();
        if (!auth)
          return { success: false, error: "NOT_AUTHENTICATED" };
        const result = await WithusApi.launchSession(
          orgId,
          sessionId,
          "Browser extension autofill",
          auth.accessToken
        );
        let username = "";
        let password = "";
        if (result.plaintext.includes("\n")) {
          const parts = result.plaintext.split("\n");
          username = parts[0].trim();
          password = parts.slice(1).join("\n").trim();
        } else if (result.plaintext.includes(":")) {
          const parts = result.plaintext.split(":");
          username = parts[0].trim();
          password = parts.slice(1).join(":").trim();
        } else if (result.plaintext.includes(" ")) {
          const spaceIdx = result.plaintext.indexOf(" ");
          const firstToken = result.plaintext.slice(0, spaceIdx);
          const rest = result.plaintext.slice(spaceIdx + 1);
          if (firstToken.includes("@") || firstToken.length < 50) {
            username = firstToken;
            password = rest;
          } else {
            username = "";
            password = result.plaintext;
          }
        } else {
          username = "";
          password = result.plaintext;
        }
        return { success: true, data: { username, password } };
      }
      case "LOGOUT": {
        const auth = await Storage.getAuth();
        if (auth?.refreshToken) {
          await WithusApi.logout(auth.refreshToken).catch(() => {
          });
        }
        await Storage.clearAuth();
        return { success: true };
      }
      case "FETCH_OTP": {
        const { sessionId, orgId, platform, loginStartTime } = msg.payload;
        const auth = await Storage.getAuth();
        if (!auth)
          return { success: false, error: "NOT_AUTHENTICATED" };
        const result = await WithusApi.fetchOtp(orgId, sessionId, auth.accessToken, platform, loginStartTime);
        return { success: true, data: { otp: result.otp } };
      }
      case "PLATFORM_ACTIVE": {
        const { platform, orgId } = msg.payload;
        const tabId = sender?.tab?.id;
        if (tabId !== void 0) {
          Storage.setTabPresence(tabId, { platform, orgId }).catch(() => {
          });
        }
        return { success: true };
      }
      case "PLATFORM_GONE": {
        const tabId = sender?.tab?.id;
        if (tabId !== void 0) {
          Storage.clearTabPresence(tabId).catch(() => {
          });
        }
        return { success: true };
      }
      default:
        return { success: false, error: `Unknown message type: ${msg.type}` };
    }
  }
})();
