"use strict";
(() => {
  // src/lib/storage.ts
  var AUTH_KEY = "withus_auth";
  var Storage = {
    async getAuth() {
      const result = await chrome.storage.local.get(AUTH_KEY);
      return result[AUTH_KEY] ?? null;
    },
    async setAuth(auth) {
      await chrome.storage.local.set({ [AUTH_KEY]: auth });
    },
    async clearAuth() {
      await chrome.storage.local.remove(AUTH_KEY);
    },
    async isAuthenticated() {
      const auth = await Storage.getAuth();
      if (!auth)
        return false;
      return Date.now() < auth.expiresAt - 6e4;
    }
  };

  // src/lib/api.ts
  var BASE_URL = ("https://withus-vault.vercel.app/api/v1" ? "https://withus-vault.vercel.app/api/v1" : null) ?? "http://127.0.0.1:4000/api/v1";
  async function request(method, path, body, token) {
    const headers = {
      "Content-Type": "application/json",
      "X-Extension-Client": "withus-mv3"
    };
    if (token)
      headers["Authorization"] = `Bearer ${token}`;
    const res = await fetch(`${BASE_URL}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : void 0
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    return res.json();
  }
  var WithusApi = {
    // ─── Auth ──────────────────────────────────────────────────────────────────
    async login(email, password) {
      const res = await request("POST", "/auth/login", { email, password });
      return {
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
        userId: res.user.id,
        email: res.user.email,
        expiresAt: Date.now() + 60 * 60 * 1e3
      };
    },
    async refresh(refreshToken) {
      const auth = await Storage.getAuth();
      const res = await request("POST", "/auth/refresh", { refreshToken });
      return {
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
        userId: res.user?.id || auth?.userId || "",
        email: res.user?.email || auth?.email || "",
        expiresAt: Date.now() + 60 * 60 * 1e3
      };
    },
    async logout(refreshToken) {
      await request("POST", "/auth/logout", { refreshToken });
    },
    // ─── Me / Org ──────────────────────────────────────────────────────────────
    async getMe(token) {
      return request("GET", "/users/me", void 0, token);
    },
    // ─── Sessions ─────────────────────────────────────────────────────────────
    async getIncomingSessions(orgId, token) {
      return request("GET", `/organizations/${orgId}/sessions/incoming`, void 0, token);
    },
    // ─── Launch Session (Extension) ───────────────────────────────────────────
    async launchSession(orgId, sessionId, reason, token) {
      return request("POST", `/organizations/${orgId}/sessions/${sessionId}/reveal`, { reason }, token);
    },
    // ─── OTP Fetch ────────────────────────────────────────────────────────────
    /**
     * Requests the latest OTP from the grantor's Gmail inbox.
     * Returns only { otp: string } — no email content ever crosses this boundary.
     *
     * OTP Boundary Rule: this is the only place in the extension that calls /otp.
     * The content script receives only the extracted code string.
     */
    async fetchOtp(orgId, sessionId, token, platform, loginStartTime) {
      return request("POST", `/organizations/${orgId}/sessions/${sessionId}/otp`, { platform, loginStartTime }, token);
    }
  };

  // src/background/service-worker.ts
  chrome.alarms.create("token-refresh", { periodInMinutes: 50 });
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name !== "token-refresh")
      return;
    const auth = await Storage.getAuth();
    if (!auth?.refreshToken)
      return;
    try {
      const fresh = await WithusApi.refresh(auth.refreshToken);
      await Storage.setAuth(fresh);
    } catch {
      await Storage.clearAuth();
    }
  });
  chrome.runtime.onInstalled.addListener(() => {
    if (chrome.privacy && chrome.privacy.services && chrome.privacy.services.passwordSavingEnabled) {
      chrome.privacy.services.passwordSavingEnabled.set({ value: false, scope: "regular" }).catch(() => {
      });
    }
  });
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      handleMessage(message).then(sendResponse).catch((err) => sendResponse({ success: false, error: String(err?.message || err) }));
      return true;
    }
  );
  async function handleMessage(msg) {
    switch (msg.type) {
      case "CHECK_AUTH": {
        const auth = await Storage.getAuth();
        if (!auth)
          return { success: false, error: "NOT_AUTHENTICATED" };
        const isValid = await Storage.isAuthenticated();
        if (!isValid)
          return { success: false, error: "TOKEN_EXPIRED" };
        return { success: true, data: { email: auth.email } };
      }
      case "GET_ACTIVE_SESSION": {
        const { domain } = msg.payload;
        const auth = await Storage.getAuth();
        if (!auth)
          return { success: false, error: "NOT_AUTHENTICATED" };
        const me = await WithusApi.getMe(auth.accessToken);
        const memberships = me.organizationMemberships || [];
        if (memberships.length === 0)
          return { success: false, error: "NO_ORGANIZATION" };
        let allSessions = [];
        const hostname = domain.replace(/^www\./, "");
        await Promise.all(
          memberships.map(async (m) => {
            try {
              const sessions = await WithusApi.getIncomingSessions(m.organizationId, auth.accessToken);
              const matching = sessions.filter((s) => {
                if (s.status !== "ACTIVE")
                  return false;
                if (s.expiresAt && new Date(s.expiresAt) < /* @__PURE__ */ new Date())
                  return false;
                const name = s.resourceName?.toLowerCase() || "";
                if (!name)
                  return false;
                const GENERIC = /* @__PURE__ */ new Set(["gov", "com", "net", "org", "in", "co", "www", "app", "api"]);
                const parts = hostname.split(".").filter((p) => p.length >= 3 && !GENERIC.has(p));
                return parts.some((part) => name.includes(part) || part.includes(name));
              }).map((s) => ({ ...s, __orgId: m.organizationId }));
              allSessions = allSessions.concat(matching);
            } catch (e) {
            }
          })
        );
        return {
          success: true,
          data: { sessions: allSessions, orgId: memberships[0].organizationId }
          // orgId kept for backwards compat
        };
      }
      case "LAUNCH_SESSION": {
        const { sessionId, orgId } = msg.payload;
        const auth = await Storage.getAuth();
        if (!auth)
          return { success: false, error: "NOT_AUTHENTICATED" };
        const result = await WithusApi.launchSession(
          orgId,
          sessionId,
          "Browser extension autofill",
          auth.accessToken
        );
        let username = "";
        let password = "";
        if (result.plaintext.includes("\n")) {
          const parts = result.plaintext.split("\n");
          username = parts[0].trim();
          password = parts.slice(1).join("\n").trim();
        } else if (result.plaintext.includes(":")) {
          const parts = result.plaintext.split(":");
          username = parts[0].trim();
          password = parts.slice(1).join(":").trim();
        } else if (result.plaintext.includes(" ")) {
          const spaceIdx = result.plaintext.indexOf(" ");
          const firstToken = result.plaintext.slice(0, spaceIdx);
          const rest = result.plaintext.slice(spaceIdx + 1);
          if (firstToken.includes("@") || firstToken.length < 50) {
            username = firstToken;
            password = rest;
          } else {
            username = "";
            password = result.plaintext;
          }
        } else {
          username = "";
          password = result.plaintext;
        }
        return { success: true, data: { username, password } };
      }
      case "LOGOUT": {
        const auth = await Storage.getAuth();
        if (auth?.refreshToken) {
          await WithusApi.logout(auth.refreshToken).catch(() => {
          });
        }
        await Storage.clearAuth();
        return { success: true };
      }
      case "FETCH_OTP": {
        const { sessionId, orgId, platform, loginStartTime } = msg.payload;
        const auth = await Storage.getAuth();
        if (!auth)
          return { success: false, error: "NOT_AUTHENTICATED" };
        const result = await WithusApi.fetchOtp(orgId, sessionId, auth.accessToken, platform, loginStartTime);
        return { success: true, data: { otp: result.otp } };
      }
      default:
        return { success: false, error: `Unknown message type: ${msg.type}` };
    }
  }
})();
